export function calculateAge(birthDate: string): number {
  const today = new Date();
  const birth = new Date(birthDate);
  
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  
  return age;
}

export function determineAgeCategory(birthDate: string, kidMaxAge: number = 18): 'enfant' | 'adulte' {
  const age = calculateAge(birthDate);
  return age < kidMaxAge ? 'enfant' : 'adulte';
}

export function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('fr-FR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

export function isValidDate(dateString: string): boolean {
  const date = new Date(dateString);
  return date instanceof Date && !isNaN(date.getTime());
}

export function getMaxBirthDate(): string {
  const date = new Date();
  date.setFullYear(date.getFullYear() - 4); // Âge minimum 4 ans
  return date.toISOString().split('T')[0];
}

export function getMinBirthDate(): string {
  const date = new Date();
  date.setFullYear(date.getFullYear() - 99); // Âge maximum 99 ans
  return date.toISOString().split('T')[0];
}