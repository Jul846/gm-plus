import type { Member } from '../types/member';
import { getSkillLevelDifference } from './tennisLevels';
import { calculateAge } from './dateUtils';

export type WeightConfig = {
  skillLevel: number;
  attendance: number;
  availability: number;
  age: number;
  gender: number;
};

export const DEFAULT_WEIGHTS: WeightConfig = {
  skillLevel: 0.4,
  attendance: 0.2,
  availability: 0.3,
  age: 0.1,
  gender: 0.2,
};

function calculateAvailabilityScore(member1: Member, member2: Member): number {
  // Vérifier si les membres ont des disponibilités définies
  if (!member1.availability || !member2.availability) {
    return 0;
  }

  let commonDays = 0;
  let totalDays = 0;

  // Parcourir tous les jours possibles
  const days = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
  
  for (const day of days) {
    const avail1 = member1.availability[day];
    const avail2 = member2.availability[day];

    // Vérifier si les disponibilités du jour sont définies pour les deux membres
    if (!avail1 || !avail2) continue;

    if (avail1.available && avail2.available && avail1.timeSlots && avail2.timeSlots) {
      // Vérifier les créneaux horaires qui se chevauchent
      const slots1 = avail1.timeSlots;
      const slots2 = avail2.timeSlots;
      
      let hasCommonSlot = false;
      for (const slot1 of slots1) {
        for (const slot2 of slots2) {
          if (slot1.hour === slot2.hour && slot1.minute === slot2.minute) {
            hasCommonSlot = true;
            break;
          }
        }
        if (hasCommonSlot) break;
      }
      
      if (hasCommonSlot) {
        commonDays++;
      }
    }
    
    if ((avail1.available && avail1.timeSlots?.length > 0) || 
        (avail2.available && avail2.timeSlots?.length > 0)) {
      totalDays++;
    }
  }

  return totalDays === 0 ? 0 : commonDays / totalDays;
}

function calculateAgeScore(member1: Member, member2: Member): number {
  const age1 = calculateAge(member1.birthDate);
  const age2 = calculateAge(member2.birthDate);
  
  // Pour les enfants, on veut des groupes d'âge très proches
  if (member1.ageCategory === 'enfant' && member2.ageCategory === 'enfant') {
    const ageDiff = Math.abs(age1 - age2);
    return ageDiff <= 2 ? 1 :
           ageDiff <= 3 ? 0.7 :
           ageDiff <= 4 ? 0.4 :
           0;
  }
  
  // Pour les adultes, on est plus flexible
  if (member1.ageCategory === 'adulte' && member2.ageCategory === 'adulte') {
    const ageDiff = Math.abs(age1 - age2);
    return ageDiff <= 5 ? 1 :
           ageDiff <= 10 ? 0.8 :
           ageDiff <= 15 ? 0.6 :
           ageDiff <= 20 ? 0.4 :
           0.2;
  }
  
  // Si un est enfant et l'autre adulte, score minimal
  return 0;
}

function calculateGenderScore(member1: Member, member2: Member): number {
  return member1.gender === member2.gender ? 1 : 0.5;
}

export function calculateGroupCompatibilityScore(members: Member[], weights = DEFAULT_WEIGHTS): number {
  if (members.length < 2) return 1;

  let totalScore = 0;
  let comparisons = 0;

  for (let i = 0; i < members.length; i++) {
    for (let j = i + 1; j < members.length; j++) {
      const availabilityScore = calculateAvailabilityScore(members[i], members[j]);
      const skillLevelScore = calculateSkillLevelScore(members[i], members[j]);
      const ageScore = calculateAgeScore(members[i], members[j]);
      const genderScore = calculateGenderScore(members[i], members[j]);

      const pairScore = 
        (skillLevelScore * weights.skillLevel) +
        (availabilityScore * weights.availability) +
        (ageScore * weights.age) +
        (genderScore * weights.gender);

      totalScore += pairScore;
      comparisons++;
    }
  }

  return comparisons > 0 ? totalScore / comparisons : 0;
}

export function calculateSkillLevelScore(member1: Member, member2: Member): number {
  // Si les membres ne sont pas de la même catégorie d'âge, retourner 0
  if (member1.ageCategory !== member2.ageCategory) return 0;

  const levelDiff = getSkillLevelDifference(member1.skillLevel, member2.skillLevel);
  
  if (member1.ageCategory === 'enfant') {
    // Pour les enfants, on veut des groupes très homogènes
    return levelDiff === 0 ? 1 :
           levelDiff === 1 ? 0.5 :
           0;
  } else {
    // Pour les adultes, on utilise l'échelle FFT
    // On considère qu'une différence de 2 classements est acceptable
    return levelDiff === 0 ? 1 :
           levelDiff === 1 ? 0.7 :
           levelDiff === 2 ? 0.4 :
           0;
  }
}