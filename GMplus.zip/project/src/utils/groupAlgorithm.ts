import type { Member } from '../types/member';

export function createHomogeneousGroups(
  members: Member[],
  numberOfGroups: number
): Member[][] {
  // Sort members by attendance frequency and skill level
  const sortedMembers = [...members].sort((a, b) => {
    const frequencyOrder = { intensive: 3, regular: 2, occasional: 1 };
    const skillOrder = { advanced: 3, intermediate: 2, beginner: 1 };
    
    // First sort by attendance frequency
    const freqDiff = frequencyOrder[b.attendanceFrequency] - frequencyOrder[a.attendanceFrequency];
    if (freqDiff !== 0) return freqDiff;
    
    // Then by skill level
    return skillOrder[b.skillLevel] - skillOrder[a.skillLevel];
  });

  // Initialize groups
  const groups: Member[][] = Array.from({ length: numberOfGroups }, () => []);
  
  // Distribute members using round-robin to ensure even distribution
  sortedMembers.forEach((member, index) => {
    const groupIndex = index % numberOfGroups;
    groups[groupIndex].push(member);
  });

  return groups;
}