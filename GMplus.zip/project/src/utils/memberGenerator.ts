import { Member, Gender, AdultSkillLevel, KidSkillLevel, GeneralLevel } from '../types/member';
import { FFT_ADULT_LEVELS, FFT_KID_LEVELS, GALAXIE_LEVELS, GENERAL_LEVELS } from './tennisLevels';

const FRENCH_FIRST_NAMES_M = [
  'Thomas', 'Nicolas', 'Antoine', 'Pierre', 'Lucas', 'Louis', 'Maxime', 'Alexandre',
  'Hugo', 'Paul', 'Arthur', 'Jules', 'Gabriel', 'Raphaël', 'Léo', 'Victor',
  'Nathan', 'Mathis', 'Théo', 'Adam', 'Ethan', 'Noah', 'Liam', 'Gabin'
];

const FRENCH_FIRST_NAMES_F = [
  'Emma', 'Louise', 'Alice', 'Chloé', 'Inès', 'Léa', 'Manon', 'Sarah',
  'Julie', 'Marie', 'Camille', 'Clara', 'Lina', 'Anna', 'Léna', 'Zoé',
  'Eva', 'Jade', 'Nina', 'Rose', 'Alix', 'Juliette', 'Sofia', 'Charlotte'
];

const FRENCH_LAST_NAMES = [
  'Martin', 'Bernard', 'Dubois', 'Thomas', 'Robert', 'Richard', 'Petit', 'Durand',
  'Leroy', 'Moreau', 'Simon', 'Laurent', 'Lefebvre', 'Michel', 'Garcia', 'David',
  'Bertrand', 'Roux', 'Vincent', 'Fournier', 'Morel', 'Girard', 'Andre', 'Lambert'
];

function getRandomElement<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)];
}

function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateRandomTimeSlots() {
  const numSlots = getRandomInt(1, 3);
  const slots = [];
  for (let i = 0; i < numSlots; i++) {
    slots.push({
      hour: getRandomInt(8, 20),
      minute: getRandomInt(0, 3) * 15
    });
  }
  return slots.sort((a, b) => a.hour - b.hour || a.minute - b.minute);
}

function generateRandomAvailability() {
  const days = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
  const availability: Record<string, any> = {};
  
  // Chaque membre est disponible 2-4 jours par semaine
  const numDays = getRandomInt(2, 4);
  const availableDays = [...days].sort(() => Math.random() - 0.5).slice(0, numDays);
  
  days.forEach(day => {
    availability[day] = {
      available: availableDays.includes(day),
      timeSlots: availableDays.includes(day) ? generateRandomTimeSlots() : []
    };
  });
  
  return availability;
}

function generateRandomBirthDate(minAge: number, maxAge: number): string {
  const today = new Date();
  const minDate = new Date(today.getFullYear() - maxAge, today.getMonth(), today.getDate());
  const maxDate = new Date(today.getFullYear() - minAge, today.getMonth(), today.getDate());
  const randomDate = new Date(minDate.getTime() + Math.random() * (maxDate.getTime() - minDate.getTime()));
  return randomDate.toISOString().split('T')[0];
}

function generateRandomEmail(firstName: string, lastName: string): string {
  const randomNum = Math.floor(Math.random() * 1000);
  return `${firstName.toLowerCase()}.${lastName.toLowerCase()}${randomNum}@example.com`;
}

export function generateRandomMember(): Omit<Member, 'id' | 'createdAt' | 'updatedAt'> {
  const gender: Gender = Math.random() > 0.5 ? 'homme' : 'femme';
  const firstName = gender === 'homme' 
    ? getRandomElement(FRENCH_FIRST_NAMES_M)
    : getRandomElement(FRENCH_FIRST_NAMES_F);
  const lastName = getRandomElement(FRENCH_LAST_NAMES);
  
  // 80% de chance d'être un adulte
  const isAdult = Math.random() < 0.8;
  const birthDate = isAdult 
    ? generateRandomBirthDate(18, 70)
    : generateRandomBirthDate(6, 17);
  
  const hasFFTRanking = Math.random() < 0.7; // 70% ont un classement FFT
  
  let skillLevel: AdultSkillLevel | KidSkillLevel;
  if (isAdult) {
    skillLevel = hasFFTRanking
      ? getRandomElement(FFT_ADULT_LEVELS)
      : getRandomElement(GENERAL_LEVELS) as AdultSkillLevel;
  } else {
    skillLevel = hasFFTRanking
      ? getRandomElement([...GALAXIE_LEVELS, ...FFT_KID_LEVELS])
      : getRandomElement(GALAXIE_LEVELS);
  }

  const generalLevel = getRandomElement(GENERAL_LEVELS);
  
  return {
    firstName,
    lastName,
    email: generateRandomEmail(firstName, lastName),
    gender,
    birthDate,
    ageCategory: isAdult ? 'adulte' : 'enfant',
    skillLevel,
    generalLevel,
    hasFFTRanking,
    sessionsPerWeek: getRandomInt(1, 3),
    availability: generateRandomAvailability()
  };
}