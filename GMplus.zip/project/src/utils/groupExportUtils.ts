import { utils, write } from 'xlsx';
import Papa from 'papaparse';
import type { Member } from '../types/member';

function formatGroupForExport(group: Member[], groupIndex: number) {
  return group.map(member => ({
    groupe: `Groupe ${groupIndex + 1}`,
    nom: member.firstName,
    prenom: member.lastName,
    email: member.email,
    genre: member.gender === 'homme' ? 'Homme' : 'Femme',
    dateNaissance: member.birthDate,
    categorie: member.ageCategory === 'adulte' ? 'Adulte' : 'Enfant',
    niveau: member.skillLevel,
    niveauGeneral: member.generalLevel,
    seancesParSemaine: member.sessionsPerWeek,
    disponibilites: Object.entries(member.availability)
      .filter(([_, value]) => value.available)
      .map(([day, value]) => {
        const timeSlots = value.timeSlots
          .map(slot => `${slot.hour.toString().padStart(2, '0')}:${slot.minute.toString().padStart(2, '0')}`)
          .join(';');
        return `${day}(${timeSlots})`;
      })
      .join(' | ')
  }));
}

export const groupExportUtils = {
  async toExcel(groups: Member[][], filename = 'groupes.xlsx') {
    const flatGroups = groups.flatMap((group, index) => 
      formatGroupForExport(group, index)
    );

    const worksheet = utils.json_to_sheet(flatGroups);
    const workbook = utils.book_new();
    utils.book_append_sheet(workbook, worksheet, 'Groupes');
    
    // Ajuster la largeur des colonnes
    const maxWidth = Object.keys(flatGroups[0] || {}).reduce((acc, key) => {
      acc[key] = Math.max(20, key.length + 2);
      return acc;
    }, {} as { [key: string]: number });
    worksheet['!cols'] = Object.values(maxWidth).map(width => ({ width }));

    const excelBuffer = write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
    
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  async toCSV(groups: Member[][], filename = 'groupes.csv') {
    const flatGroups = groups.flatMap((group, index) => 
      formatGroupForExport(group, index)
    );

    const csv = Papa.unparse(flatGroups, {
      delimiter: ',',
      header: true,
      encoding: 'utf-8'
    });
    
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csv], {
      type: 'text/csv;charset=utf-8;'
    });
    
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  async toJSON(groups: Member[][], filename = 'groupes.json') {
    const formattedGroups = groups.map((group, index) => ({
      groupId: index + 1,
      members: formatGroupForExport(group, index)
    }));

    const json = JSON.stringify(formattedGroups, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
};