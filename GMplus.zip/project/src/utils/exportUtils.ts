import { utils, write } from 'xlsx';
import Papa from 'papaparse';
import type { Member } from '../types/member';

// Fonction pour convertir un membre en format plat pour l'export
function flattenMember(member: Member) {
  const availabilityString = Object.entries(member.availability)
    .filter(([_, value]) => value.available)
    .map(([day, value]) => {
      const timeSlots = value.timeSlots
        .map(slot => `${slot.hour.toString().padStart(2, '0')}:${slot.minute.toString().padStart(2, '0')}`)
        .join(';');
      return `${day}(${timeSlots})`;
    })
    .join('|');

  return {
    id: member.id,
    firstName: member.firstName,
    lastName: member.lastName,
    email: member.email,
    gender: member.gender,
    birthDate: member.birthDate,
    ageCategory: member.ageCategory,
    skillLevel: member.skillLevel,
    generalLevel: member.generalLevel,
    hasFFTRanking: member.hasFFTRanking ? 'true' : 'false',
    sessionsPerWeek: member.sessionsPerWeek,
    availability: availabilityString,
    createdAt: member.createdAt,
    updatedAt: member.updatedAt
  };
}

// Fonction pour reconstruire un membre à partir du format plat
function unflattenMember(flatMember: any): Partial<Member> {
  const availability: Record<string, any> = {};
  const days = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
  
  // Initialiser tous les jours comme non disponibles
  days.forEach(day => {
    availability[day] = {
      available: false,
      timeSlots: []
    };
  });
  
  if (flatMember.availability) {
    flatMember.availability.split('|').forEach((daySlot: string) => {
      const match = daySlot.match(/^(\w+)\((.*)\)$/);
      if (match) {
        const [_, day, timeSlots] = match;
        if (days.includes(day)) {
          availability[day] = {
            available: true,
            timeSlots: timeSlots.split(';').map((timeStr: string) => {
              const [hour, minute] = timeStr.split(':').map(Number);
              return { hour, minute };
            })
          };
        }
      }
    });
  }

  return {
    firstName: flatMember.firstName,
    lastName: flatMember.lastName,
    email: flatMember.email,
    gender: flatMember.gender,
    birthDate: flatMember.birthDate,
    ageCategory: flatMember.ageCategory,
    skillLevel: flatMember.skillLevel,
    generalLevel: flatMember.generalLevel,
    hasFFTRanking: String(flatMember.hasFFTRanking).toLowerCase() === 'true',
    sessionsPerWeek: Number(flatMember.sessionsPerWeek) || 1,
    availability
  };
}

export const exportUtils = {
  // Export au format Excel
  async toExcel(members: Member[], filename = 'membres.xlsx') {
    const flatMembers = members.map(flattenMember);
    const worksheet = utils.json_to_sheet(flatMembers);
    const workbook = utils.book_new();
    utils.book_append_sheet(workbook, worksheet, 'Membres');
    const excelBuffer = write(workbook, { bookType: 'xlsx', type: 'array' });
    
    const blob = new Blob([excelBuffer], { 
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
    });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  // Export au format CSV
  async toCSV(members: Member[], filename = 'membres.csv') {
    const flatMembers = members.map(flattenMember);
    const csv = Papa.unparse(flatMembers, {
      delimiter: ',',
      header: true,
      encoding: 'utf-8'
    });
    
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csv], { 
      type: 'text/csv;charset=utf-8;' 
    });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  // Export au format JSON
  async toJSON(members: Member[], filename = 'membres.json') {
    const json = JSON.stringify(members, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  // Import depuis un fichier Excel, CSV ou JSON
  async fromFile(file: File): Promise<Partial<Member>[]> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = async (e) => {
        try {
          const extension = file.name.split('.').pop()?.toLowerCase();
          let data: any[] = [];

          if (extension === 'xlsx' || extension === 'xls') {
            const buffer = e.target?.result;
            const workbook = utils.read(buffer, { type: 'array' });
            const sheetName = workbook.SheetNames[0];
            data = utils.sheet_to_json(workbook.Sheets[sheetName]);
          } else if (extension === 'csv') {
            const text = e.target?.result as string;
            const result = Papa.parse(text, {
              header: true,
              skipEmptyLines: true,
              encoding: 'utf-8'
            });
            data = result.data;
          } else if (extension === 'json') {
            data = JSON.parse(e.target?.result as string);
          } else {
            throw new Error('Format de fichier non supporté');
          }

          const members = data.map(unflattenMember);
          resolve(members);
        } catch (error) {
          reject(error);
        }
      };

      reader.onerror = () => {
        reject(new Error('Erreur lors de la lecture du fichier'));
      };

      if (file.name.endsWith('.json')) {
        reader.readAsText(file);
      } else if (file.name.endsWith('.csv')) {
        reader.readAsText(file);
      } else {
        reader.readAsArrayBuffer(file);
      }
    });
  }
};