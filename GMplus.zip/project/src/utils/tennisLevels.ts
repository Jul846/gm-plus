import type { AdultSkillLevel, KidSkillLevel, GeneralLevel } from '../types/member';

export const GENERAL_LEVELS: GeneralLevel[] = [
  'DEBUTANT',
  'DEBUTANT_PLUS',
  'INTERMEDIAIRE',
  'INTERMEDIAIRE_PLUS',
  'AVANCE',
  'AVANCE_PLUS'
];

export const GENERAL_LEVEL_LABELS: Record<GeneralLevel, string> = {
  'DEBUTANT': 'Débutant',
  'DEBUTANT_PLUS': 'Débutant+',
  'INTERMEDIAIRE': 'Intermédiaire',
  'INTERMEDIAIRE_PLUS': 'Intermédiaire+',
  'AVANCE': 'Avancé',
  'AVANCE_PLUS': 'Avancé+'
};

export const FFT_ADULT_LEVELS: AdultSkillLevel[] = [
  'NC', '40', '30/5', '30/4', '30/3', '30/2', '30/1',
  '15/5', '15/4', '15/3', '15/2', '15/1',
  '4/6', '3/6', '2/6', '1/6', '0', '-2/6', '-4/6', '-15', 'PRO'
];

export const FFT_KID_LEVELS: KidSkillLevel[] = [
  'NC', '40', '30/5', '30/4', '30/3', '30/2', '30/1'
];

export const GALAXIE_LEVELS: KidSkillLevel[] = [
  'GALAXIE_BLANC',    // 4-5 ans - Découverte du tennis
  'GALAXIE_VIOLET',   // 5-6 ans - Initiation
  'GALAXIE_ROUGE',    // 6-7 ans - Mini-tennis
  'GALAXIE_ORANGE',   // 7-8 ans - Terrain intermédiaire
  'GALAXIE_VERT',     // 8-9 ans - Terrain normal
  'COMPETITION_11',   // 9-11 ans - Compétition
  'COMPETITION_12',   // 11-12 ans - Compétition
  'COMPETITION_13',   // 12-13 ans - Compétition
  'COMPETITION_14'    // 13-14 ans - Compétition
];

export const GALAXIE_LEVEL_LABELS: Record<KidSkillLevel, string> = {
  'GALAXIE_BLANC': 'Galaxie Blanc (4-5 ans)',
  'GALAXIE_VIOLET': 'Galaxie Violet (5-6 ans)',
  'GALAXIE_ROUGE': 'Galaxie Rouge (6-7 ans)',
  'GALAXIE_ORANGE': 'Galaxie Orange (7-8 ans)',
  'GALAXIE_VERT': 'Galaxie Vert (8-9 ans)',
  'COMPETITION_11': 'Compétition 9-11 ans',
  'COMPETITION_12': 'Compétition 11-12 ans',
  'COMPETITION_13': 'Compétition 12-13 ans',
  'COMPETITION_14': 'Compétition 13-14 ans',
  ...GENERAL_LEVEL_LABELS,
  'NC': 'Non Classé',
  '40': '40',
  '30/5': '30/5',
  '30/4': '30/4',
  '30/3': '30/3',
  '30/2': '30/2',
  '30/1': '30/1'
};

export function isGeneralLevel(level: string): level is GeneralLevel {
  return GENERAL_LEVELS.includes(level as GeneralLevel);
}

export function isFFTLevel(level: string): boolean {
  return FFT_ADULT_LEVELS.includes(level as AdultSkillLevel) || 
         FFT_KID_LEVELS.includes(level as KidSkillLevel);
}

export function isGalaxieLevel(level: string): boolean {
  return GALAXIE_LEVELS.includes(level as KidSkillLevel);
}

export function getFFTLevelValue(level: string): number {
  if (!isFFTLevel(level)) return -1;
  return FFT_ADULT_LEVELS.indexOf(level as AdultSkillLevel);
}

export function getGeneralLevelValue(level: GeneralLevel): number {
  return GENERAL_LEVELS.indexOf(level);
}

export function getSkillLevelDifference(level1: string, level2: string): number {
  // Si les deux niveaux sont des classements FFT
  if (isFFTLevel(level1) && isFFTLevel(level2)) {
    return Math.abs(getFFTLevelValue(level1) - getFFTLevelValue(level2));
  }
  
  // Si les deux niveaux sont des niveaux généraux
  if (isGeneralLevel(level1) && isGeneralLevel(level2)) {
    return Math.abs(getGeneralLevelValue(level1 as GeneralLevel) - getGeneralLevelValue(level2 as GeneralLevel));
  }
  
  // Si les deux niveaux sont des niveaux Galaxie
  if (isGalaxieLevel(level1) && isGalaxieLevel(level2)) {
    return Math.abs(GALAXIE_LEVELS.indexOf(level1 as KidSkillLevel) - GALAXIE_LEVELS.indexOf(level2 as KidSkillLevel));
  }
  
  // Si les niveaux ne sont pas comparables
  return 999;
}

export function getRecommendedGeneralLevel(fftLevel: string): GeneralLevel {
  if (!isFFTLevel(fftLevel)) return 'DEBUTANT';
  
  const levelValue = getFFTLevelValue(fftLevel);
  
  if (levelValue <= 2) return 'DEBUTANT'; // NC, 40, 30/5
  if (levelValue <= 4) return 'DEBUTANT_PLUS'; // 30/4, 30/3
  if (levelValue <= 6) return 'INTERMEDIAIRE'; // 30/2, 30/1
  if (levelValue <= 8) return 'INTERMEDIAIRE_PLUS'; // 15/5, 15/4
  if (levelValue <= 11) return 'AVANCE'; // 15/3, 15/2, 15/1
  return 'AVANCE_PLUS'; // Reste des classements
}

export function getRecommendedGroupSize(level: string): number {
  if (isGalaxieLevel(level)) {
    return level.startsWith('GALAXIE_') ? 6 : 8;
  }
  
  if (isFFTLevel(level)) {
    const levelValue = getFFTLevelValue(level);
    return levelValue <= 4 ? 6 : 4; // Groupes plus petits pour les niveaux avancés
  }
  
  if (isGeneralLevel(level)) {
    const levelValue = getGeneralLevelValue(level as GeneralLevel);
    return levelValue <= 2 ? 6 : 4;
  }
  
  return 6; // Taille par défaut
}