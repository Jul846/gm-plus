export type LeaderRole = 'head_coach' | 'coach' | 'assistant';

export interface Leader {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  role: LeaderRole;
  specialties?: string[];
  availability?: Record<string, boolean>;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}