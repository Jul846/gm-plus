export interface GroupMemberComment {
  memberId: string;
  comment: string;
  updatedAt: string;
  updatedBy: string;
}

export interface Group {
  id: string;
  name: string;
  members: string[]; // Member IDs
  groupComment?: string;
  memberComments: GroupMemberComment[];
  createdAt: string;
  updatedAt: string;
  updatedBy: string;
}