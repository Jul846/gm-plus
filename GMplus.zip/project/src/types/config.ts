import type { WeightConfig } from '../utils/groupUtils';

export interface TennisConfig {
  id: string;
  // ... autres configurations ...
  grouping: {
    weights: WeightConfig;
    maxSizeDifference: number;
    minGroupSize: number;
    maxGroupSize: number;
    defaultGroupCount: number;
    defaultMembersPerGroup: number;
    groupingMode: 'byCount' | 'bySize'; // Nouveau mode de groupage
  };
  // ... reste de la configuration ...
}