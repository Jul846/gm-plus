export type GeneralLevel = 
  | 'DEBUTANT'
  | 'DEBUTANT_PLUS'
  | 'INTERMEDIAIRE'
  | 'INTERMEDIAIRE_PLUS'
  | 'AVANCE'
  | 'AVANCE_PLUS';

export type AdultSkillLevel = 
  | GeneralLevel
  | 'NC' | '40' | '30/5' | '30/4' | '30/3' | '30/2' | '30/1'
  | '15/5' | '15/4' | '15/3' | '15/2' | '15/1'
  | '4/6' | '3/6' | '2/6' | '1/6' | '0' | '-2/6' | '-4/6' | '-15' | 'PRO';

export type KidSkillLevel = 
  | GeneralLevel
  | 'GALAXIE_BLANC' 
  | 'GALAXIE_VIOLET' 
  | 'GALAXIE_ROUGE' 
  | 'GALAXIE_ORANGE' 
  | 'GALAXIE_VERT'
  | 'COMPETITION_11'
  | 'COMPETITION_12'
  | 'COMPETITION_13'
  | 'COMPETITION_14'
  | 'NC' | '40' | '30/5' | '30/4' | '30/3' | '30/2' | '30/1';

export type AgeCategory = 'enfant' | 'adulte';
export type Gender = 'homme' | 'femme';
export type AttendanceFrequency = 'occasionnel' | 'regulier' | 'intensif';

export interface TimeSlot {
  hour: number;
  minute: number;
}

export interface Availability {
  available: boolean;
  timeSlots: TimeSlot[];
}

export interface Member {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  gender: Gender;
  birthDate: string; // Format ISO: YYYY-MM-DD
  ageCategory: AgeCategory;
  skillLevel: AdultSkillLevel | KidSkillLevel;
  generalLevel: GeneralLevel;
  hasFFTRanking: boolean;
  sessionsPerWeek: number;
  availability: Record<string, Availability>;
  createdAt: string;
  updatedAt: string;
}