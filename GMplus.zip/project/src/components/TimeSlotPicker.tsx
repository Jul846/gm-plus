import React from 'react';
import type { TimeSlot } from '../types/member';

interface TimeSlotPickerProps {
  value: TimeSlot[];
  onChange: (timeSlots: TimeSlot[]) => void;
  disabled?: boolean;
}

export function TimeSlotPicker({ value, onChange, disabled }: TimeSlotPickerProps) {
  const addTimeSlot = () => {
    onChange([...value, { hour: 8, minute: 0 }]);
  };

  const removeTimeSlot = (index: number) => {
    onChange(value.filter((_, i) => i !== index));
  };

  const updateTimeSlot = (index: number, field: keyof TimeSlot, newValue: number) => {
    const newTimeSlots = [...value];
    newTimeSlots[index] = {
      ...newTimeSlots[index],
      [field]: newValue,
    };
    onChange(newTimeSlots);
  };

  return (
    <div className="space-y-2">
      {value.map((timeSlot, index) => (
        <div key={index} className="flex items-center space-x-2">
          <select
            value={timeSlot.hour}
            onChange={(e) => updateTimeSlot(index, 'hour', parseInt(e.target.value))}
            disabled={disabled}
            className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          >
            {Array.from({ length: 24 }, (_, i) => (
              <option key={i} value={i}>
                {i.toString().padStart(2, '0')}
              </option>
            ))}
          </select>
          <span>:</span>
          <select
            value={timeSlot.minute}
            onChange={(e) => updateTimeSlot(index, 'minute', parseInt(e.target.value))}
            disabled={disabled}
            className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          >
            {[0, 15, 30, 45].map((minute) => (
              <option key={minute} value={minute}>
                {minute.toString().padStart(2, '0')}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => removeTimeSlot(index)}
            disabled={disabled}
            className="text-red-600 hover:text-red-800"
          >
            ×
          </button>
        </div>
      ))}
      <button
        type="button"
        onClick={addTimeSlot}
        disabled={disabled}
        className="text-sm text-indigo-600 hover:text-indigo-800"
      >
        + Ajouter un horaire
      </button>
    </div>
  );
}