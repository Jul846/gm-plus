import React, { useRef } from 'react';
import { Download, Upload, Share2, FileSpreadsheet, FileJson, FileText } from 'lucide-react';
import { Button } from './Button';
import { exportUtils } from '../utils/exportUtils';
import type { Member } from '../types/member';
import { toast } from 'react-toastify';

interface ExportImportButtonsProps {
  members: Member[];
  onImport: (members: Partial<Member>[]) => Promise<void>;
  selectedMembers?: Member[];
}

export function ExportImportButtons({ members, onImport, selectedMembers }: ExportImportButtonsProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const membersToExport = selectedMembers || members;

  const handleExportExcel = async () => {
    if (membersToExport.length === 0) {
      toast.warning('Aucun membre à exporter');
      return;
    }
    try {
      await exportUtils.toExcel(membersToExport);
      toast.success(`${membersToExport.length} membres exportés en Excel`);
    } catch (error) {
      console.error('Export Excel error:', error);
      toast.error('Erreur lors de l\'export Excel');
    }
  };

  const handleExportCSV = async () => {
    if (membersToExport.length === 0) {
      toast.warning('Aucun membre à exporter');
      return;
    }
    try {
      await exportUtils.toCSV(membersToExport);
      toast.success(`${membersToExport.length} membres exportés en CSV`);
    } catch (error) {
      console.error('Export CSV error:', error);
      toast.error('Erreur lors de l\'export CSV');
    }
  };

  const handleExportJSON = async () => {
    if (membersToExport.length === 0) {
      toast.warning('Aucun membre à exporter');
      return;
    }
    try {
      await exportUtils.toJSON(membersToExport);
      toast.success(`${membersToExport.length} membres exportés en JSON`);
    } catch (error) {
      console.error('Export JSON error:', error);
      toast.error('Erreur lors de l\'export JSON');
    }
  };

  const handleShare = async () => {
    if (membersToExport.length === 0) {
      toast.warning('Aucun membre à partager');
      return;
    }

    try {
      // Vérifier si le navigateur supporte le partage
      if (!navigator.share) {
        throw new Error('SHARE_NOT_SUPPORTED');
      }

      // Vérifier si le partage de fichiers est supporté
      if (!navigator.canShare) {
        throw new Error('FILE_SHARE_NOT_SUPPORTED');
      }

      const blob = new Blob([JSON.stringify(membersToExport, null, 2)], { type: 'application/json' });
      const file = new File([blob], 'membres.json', { type: 'application/json' });

      // Vérifier si le fichier peut être partagé
      const shareData = { files: [file], title: 'Membres GM+', text: 'Liste des membres' };
      if (!navigator.canShare(shareData)) {
        throw new Error('FILE_SHARE_NOT_SUPPORTED');
      }

      await navigator.share(shareData);
      toast.success('Partage réussi');
    } catch (error) {
      if (error instanceof Error) {
        switch (error.message) {
          case 'SHARE_NOT_SUPPORTED':
            toast.info('Le partage n\'est pas supporté par votre navigateur. Le fichier va être téléchargé.');
            await handleExportJSON();
            break;
          case 'FILE_SHARE_NOT_SUPPORTED':
            toast.info('Le partage de fichiers n\'est pas supporté. Le fichier va être téléchargé.');
            await handleExportJSON();
            break;
          default:
            if (error.name === 'AbortError') {
              // L'utilisateur a annulé le partage, ne rien faire
              return;
            } else if (error.name === 'NotAllowedError') {
              toast.info('Le partage n\'est pas autorisé. Le fichier va être téléchargé.');
              await handleExportJSON();
            } else {
              console.error('Share error:', error);
              toast.error('Erreur lors du partage. Le fichier va être téléchargé.');
              await handleExportJSON();
            }
        }
      }
    }
  };

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const importedMembers = await exportUtils.fromFile(file);
      if (importedMembers.length === 0) {
        toast.warning('Aucun membre à importer dans le fichier');
        return;
      }
      await onImport(importedMembers);
      toast.success(`${importedMembers.length} membres importés avec succès`);
      
      // Réinitialiser l'input file
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Import error:', error);
      toast.error('Erreur lors de l\'import. Vérifiez le format du fichier.');
    }
  };

  return (
    <div className="flex flex-wrap gap-2">
      <div className="relative inline-block group">
        <Button variant="secondary" className="flex items-center">
          <Download className="h-4 w-4 mr-2" />
          Exporter
        </Button>
        <div className="hidden group-hover:block absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
          <div className="py-1">
            <button
              onClick={handleExportExcel}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Excel (.xlsx)
            </button>
            <button
              onClick={handleExportCSV}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FileText className="h-4 w-4 mr-2" />
              CSV (.csv)
            </button>
            <button
              onClick={handleExportJSON}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FileJson className="h-4 w-4 mr-2" />
              JSON (.json)
            </button>
          </div>
        </div>
      </div>

      <Button
        variant="secondary"
        onClick={() => fileInputRef.current?.click()}
        className="flex items-center"
      >
        <Upload className="h-4 w-4 mr-2" />
        Importer
      </Button>

      <Button
        variant="secondary"
        onClick={handleShare}
        className="flex items-center"
      >
        <Share2 className="h-4 w-4 mr-2" />
        Partager
      </Button>

      <input
        ref={fileInputRef}
        type="file"
        accept=".xlsx,.xls,.csv,.json"
        onChange={handleImport}
        className="hidden"
      />
    </div>
  );
}