import React, { useState } from 'react';
import { Users, MessageSquare } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useGroupStore } from '../store/groupStore';
import type { Member } from '../types/member';
import type { GroupMemberComment } from '../types/group';
import { calculateGroupCompatibilityScore } from '../utils/groupUtils';
import { Button } from './Button';
import { toast } from 'react-toastify';

interface GroupListProps {
  groups: Member[][];
}

export function GroupList({ groups }: GroupListProps) {
  const { role, user } = useAuthStore();
  const { updateGroupComment, updateMemberComment } = useGroupStore();
  const [editingGroupComment, setEditingGroupComment] = useState<number | null>(null);
  const [editingMemberComment, setEditingMemberComment] = useState<{groupIndex: number, memberId: string} | null>(null);
  const [commentText, setCommentText] = useState('');

  const canEditComments = role === 'superadmin' || role === 'supreme';

  const handleGroupCommentSave = async (groupIndex: number) => {
    try {
      await updateGroupComment(groupIndex, commentText, user!.uid);
      setEditingGroupComment(null);
      setCommentText('');
      toast.success('Commentaire du groupe mis à jour');
    } catch (error) {
      toast.error('Erreur lors de la mise à jour du commentaire');
    }
  };

  const handleMemberCommentSave = async (groupIndex: number, memberId: string) => {
    try {
      await updateMemberComment(groupIndex, memberId, commentText, user!.uid);
      setEditingMemberComment(null);
      setCommentText('');
      toast.success('Commentaire du membre mis à jour');
    } catch (error) {
      toast.error('Erreur lors de la mise à jour du commentaire');
    }
  };

  const getSkillLevelColor = (level: string) => {
    switch (level) {
      case 'debutant': return 'bg-green-100 text-green-800';
      case 'intermediaire': return 'bg-blue-100 text-blue-800';
      case 'avance': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCompatibilityColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600';
    if (score >= 0.6) return 'text-blue-600';
    if (score >= 0.4) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
      {groups.map((group, groupIndex) => {
        const compatibilityScore = calculateGroupCompatibilityScore(group);
        const groupData = useGroupStore((state) => state.groups[groupIndex]);
        
        return (
          <div key={groupIndex} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900 flex items-center">
                <Users className="h-5 w-5 mr-2 text-indigo-600" />
                Groupe {groupIndex + 1}
              </h3>
              <div className="flex flex-col items-end">
                <span className="text-sm text-gray-500">{group.length} membres</span>
                <span className={`text-sm font-medium ${getCompatibilityColor(compatibilityScore)}`}>
                  Compatibilité: {Math.round(compatibilityScore * 100)}%
                </span>
              </div>
            </div>

            {canEditComments && (
              <div className="mb-4">
                {editingGroupComment === groupIndex ? (
                  <div className="space-y-2">
                    <textarea
                      className="w-full p-2 border rounded-md"
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Commentaire du groupe..."
                      rows={3}
                    />
                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="secondary"
                        onClick={() => {
                          setEditingGroupComment(null);
                          setCommentText('');
                        }}
                      >
                        Annuler
                      </Button>
                      <Button onClick={() => handleGroupCommentSave(groupIndex)}>
                        Enregistrer
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded-md">
                    <p className="text-sm text-gray-600">
                      {groupData?.groupComment || 'Aucun commentaire'}
                    </p>
                    <button
                      onClick={() => {
                        setEditingGroupComment(groupIndex);
                        setCommentText(groupData?.groupComment || '');
                      }}
                      className="text-indigo-600 hover:text-indigo-800"
                    >
                      <MessageSquare className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>
            )}

            <ul className="space-y-3">
              {group.map((member) => (
                <li key={member.id} className="flex flex-col space-y-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-sm font-medium">
                        {member.firstName} {member.lastName}
                      </span>
                      <div className="flex space-x-2 mt-1">
                        <span className={`px-2 py-1 text-xs rounded-full ${getSkillLevelColor(member.skillLevel)}`}>
                          {member.skillLevel}
                        </span>
                      </div>
                    </div>
                    
                    {canEditComments && (
                      <div className="flex-1 ml-4">
                        {editingMemberComment?.groupIndex === groupIndex && 
                         editingMemberComment?.memberId === member.id ? (
                          <div className="space-y-2">
                            <textarea
                              className="w-full p-2 border rounded-md text-sm"
                              value={commentText}
                              onChange={(e) => setCommentText(e.target.value)}
                              placeholder="Commentaire du membre..."
                              rows={2}
                            />
                            <div className="flex justify-end space-x-2">
                              <Button
                                variant="secondary"
                                size="sm"
                                onClick={() => {
                                  setEditingMemberComment(null);
                                  setCommentText('');
                                }}
                              >
                                Annuler
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => handleMemberCommentSave(groupIndex, member.id)}
                              >
                                Enregistrer
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between p-1 bg-gray-50 rounded-md">
                            <p className="text-xs text-gray-600">
                              {groupData?.memberComments.find(c => c.memberId === member.id)?.comment || 
                               'Aucun commentaire'}
                            </p>
                            <button
                              onClick={() => {
                                setEditingMemberComment({ groupIndex, memberId: member.id });
                                setCommentText(groupData?.memberComments.find(
                                  c => c.memberId === member.id
                                )?.comment || '');
                              }}
                              className="text-indigo-600 hover:text-indigo-800 ml-2"
                            >
                              <MessageSquare className="h-3 w-3" />
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        );
      })}
    </div>
  );
}