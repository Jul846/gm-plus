import React from 'react';
import { useForm } from 'react-hook-form';
import { useConfigStore } from '../store/configStore';
import { useAuthStore } from '../store/authStore';
import { Button } from './Button';
import { Input } from './Input';
import { toast } from 'react-toastify';

interface GroupSettingsProps {
  onClose: () => void;
}

export function GroupSettings({ onClose }: GroupSettingsProps) {
  const { user } = useAuthStore();
  const { config, updateConfig } = useConfigStore();
  const { register, handleSubmit } = useForm({
    defaultValues: {
      minGroupSize: config?.grouping.minGroupSize || 2,
      maxGroupSize: config?.grouping.maxGroupSize || 8,
      defaultGroupCount: config?.grouping.defaultGroupCount || 2,
      maxSizeDifference: config?.grouping.maxSizeDifference || 1,
      weights: config?.grouping.weights || {
        skillLevel: 0.4,
        attendance: 0.2,
        availability: 0.3,
        age: 0.1,
        gender: 0.2
      }
    }
  });

  const onSubmit = async (data: any) => {
    try {
      await updateConfig({
        grouping: {
          ...config?.grouping,
          ...data
        }
      }, user!.uid);
      toast.success('Paramètres des groupes mis à jour');
      onClose();
    } catch (error) {
      toast.error('Erreur lors de la mise à jour des paramètres');
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div className="mt-3">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Paramètres des groupes
          </h3>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <Input
              label="Taille minimum des groupes"
              type="number"
              min={2}
              {...register('minGroupSize')}
            />
            <Input
              label="Taille maximum des groupes"
              type="number"
              min={2}
              {...register('maxGroupSize')}
            />
            <Input
              label="Nombre de groupes par défaut"
              type="number"
              min={2}
              {...register('defaultGroupCount')}
            />
            <Input
              label="Différence max. de taille entre groupes"
              type="number"
              min={0}
              {...register('maxSizeDifference')}
            />

            <div className="space-y-2">
              <h4 className="font-medium text-sm text-gray-700">Pondération des critères</h4>
              <Input
                label="Niveau (0-1)"
                type="number"
                step="0.1"
                min="0"
                max="1"
                {...register('weights.skillLevel')}
              />
              <Input
                label="Présence (0-1)"
                type="number"
                step="0.1"
                min="0"
                max="1"
                {...register('weights.attendance')}
              />
              <Input
                label="Disponibilité (0-1)"
                type="number"
                step="0.1"
                min="0"
                max="1"
                {...register('weights.availability')}
              />
              <Input
                label="Âge (0-1)"
                type="number"
                step="0.1"
                min="0"
                max="1"
                {...register('weights.age')}
              />
              <Input
                label="Genre (0-1)"
                type="number"
                step="0.1"
                min="0"
                max="1"
                {...register('weights.gender')}
              />
            </div>

            <div className="flex justify-end space-x-3 mt-4">
              <Button type="button" variant="secondary" onClick={onClose}>
                Annuler
              </Button>
              <Button type="submit">
                Enregistrer
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}