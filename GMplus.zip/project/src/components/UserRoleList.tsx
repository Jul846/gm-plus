import React from 'react';
import { Shield } from 'lucide-react';
import type { Role } from '../store/authStore';

interface UserRoleListProps {
  users: Array<{
    id: string;
    email: string;
    role: Role;
    createdAt: string;
  }>;
  onUpdateRole: (userId: string, newRole: Role) => Promise<void>;
}

const ROLE_OPTIONS: Role[] = ['user', 'admin', 'superadmin', 'supreme'];

export function UserRoleList({ users, onUpdateRole }: UserRoleListProps) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Email
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Rôle actuel
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Changer le rôle
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {users.map((user) => (
            <tr key={user.id}>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <Shield className={`h-5 w-5 mr-2 ${
                    user.role === 'supreme' ? 'text-yellow-500' :
                    user.role === 'superadmin' ? 'text-red-500' :
                    user.role === 'admin' ? 'text-indigo-500' :
                    'text-gray-400'
                  }`} />
                  <div className="text-sm font-medium text-gray-900">
                    {user.email}
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                  user.role === 'supreme' ? 'bg-yellow-100 text-yellow-800' :
                  user.role === 'superadmin' ? 'bg-red-100 text-red-800' :
                  user.role === 'admin' ? 'bg-indigo-100 text-indigo-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {user.role}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <select
                  value={user.role}
                  onChange={(e) => onUpdateRole(user.id, e.target.value as Role)}
                  disabled={user.role === 'supreme'} // Ne pas permettre de changer le rôle supreme
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                >
                  {ROLE_OPTIONS.map((role) => (
                    <option key={role} value={role}>
                      {role}
                    </option>
                  ))}
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}