import React from 'react';
import { Edit2, Award } from 'lucide-react';
import type { Leader } from '../types/leader';

interface LeaderListProps {
  leaders: Leader[];
  onEdit: (leader: Leader) => void;
}

const ROLE_LABELS = {
  head_coach: 'Entraîneur principal',
  coach: 'Entraîneur',
  assistant: 'Assistant'
};

export function LeaderList({ leaders, onEdit }: LeaderListProps) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Nom
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Rôle
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Contact
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Spécialités
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Statut
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {leaders.map((leader) => (
            <tr key={leader.id}>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Award className={`h-5 w-5 ${
                      leader.role === 'head_coach' ? 'text-yellow-500' :
                      leader.role === 'coach' ? 'text-indigo-500' :
                      'text-gray-400'
                    }`} />
                  </div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">
                      {leader.firstName} {leader.lastName}
                    </div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                  leader.role === 'head_coach' ? 'bg-yellow-100 text-yellow-800' :
                  leader.role === 'coach' ? 'bg-indigo-100 text-indigo-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {ROLE_LABELS[leader.role]}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{leader.email}</div>
                {leader.phone && (
                  <div className="text-sm text-gray-500">{leader.phone}</div>
                )}
              </td>
              <td className="px-6 py-4">
                <div className="flex flex-wrap gap-1">
                  {leader.specialties?.map((specialty, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                  leader.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                }`}>
                  {leader.active ? 'Actif' : 'Inactif'}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button
                  onClick={() => onEdit(leader)}
                  className="text-indigo-600 hover:text-indigo-900"
                >
                  <Edit2 className="h-4 w-4" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}