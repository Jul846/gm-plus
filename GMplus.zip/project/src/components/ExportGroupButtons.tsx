import React from 'react';
import { Download, Share2, FileSpreadsheet, FileJson, FileText } from 'lucide-react';
import { Button } from './Button';
import { groupExportUtils } from '../utils/groupExportUtils';
import type { Member } from '../types/member';
import { toast } from 'react-toastify';

interface ExportGroupButtonsProps {
  groups: Member[][];
}

export function ExportGroupButtons({ groups }: ExportGroupButtonsProps) {
  const handleExportExcel = async () => {
    try {
      await groupExportUtils.toExcel(groups);
      toast.success('Groupes exportés en Excel');
    } catch (error) {
      console.error('Export Excel error:', error);
      toast.error('Erreur lors de l\'export Excel');
    }
  };

  const handleExportCSV = async () => {
    try {
      await groupExportUtils.toCSV(groups);
      toast.success('Groupes exportés en CSV');
    } catch (error) {
      console.error('Export CSV error:', error);
      toast.error('Erreur lors de l\'export CSV');
    }
  };

  const handleExportJSON = async () => {
    try {
      await groupExportUtils.toJSON(groups);
      toast.success('Groupes exportés en JSON');
    } catch (error) {
      console.error('Export JSON error:', error);
      toast.error('Erreur lors de l\'export JSON');
    }
  };

  const handleShare = async () => {
    try {
      const blob = new Blob([JSON.stringify(groups, null, 2)], { type: 'application/json' });
      const file = new File([blob], 'groupes.json', { type: 'application/json' });

      if (navigator.share && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: 'Groupes GM+',
          text: 'Voici les groupes exportés depuis GM+'
        });
        toast.success('Partage réussi');
      } else {
        // Si le partage n'est pas supporté, on fait un export JSON classique
        await handleExportJSON();
      }
    } catch (error) {
      if (error instanceof Error && error.name !== 'AbortError') {
        console.error('Share error:', error);
        await handleExportJSON();
      }
    }
  };

  return (
    <div className="flex flex-wrap gap-2">
      <div className="relative inline-block group">
        <Button variant="secondary" className="flex items-center">
          <Download className="h-4 w-4 mr-2" />
          Exporter les groupes
        </Button>
        <div className="hidden group-hover:block absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
          <div className="py-1">
            <button
              onClick={handleExportExcel}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Excel (.xlsx)
            </button>
            <button
              onClick={handleExportCSV}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FileText className="h-4 w-4 mr-2" />
              CSV (.csv)
            </button>
            <button
              onClick={handleExportJSON}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FileJson className="h-4 w-4 mr-2" />
              JSON (.json)
            </button>
          </div>
        </div>
      </div>

      <Button
        variant="secondary"
        onClick={handleShare}
        className="flex items-center"
      >
        <Share2 className="h-4 w-4 mr-2" />
        Partager les groupes
      </Button>
    </div>
  );
}