import React from 'react';
import { useForm } from 'react-hook-form';
import { Input } from './Input';
import { Button } from './Button';
import type { Leader, LeaderRole } from '../types/leader';

interface LeaderFormProps {
  leader?: Leader | null;
  onSubmit: (data: Partial<Leader>) => Promise<void>;
  onCancel: () => void;
}

const ROLE_OPTIONS = [
  { value: 'head_coach', label: 'Entraîneur principal' },
  { value: 'coach', label: 'Entraîneur' },
  { value: 'assistant', label: 'Assistant' }
];

const SPECIALTIES = [
  'Mini-tennis',
  'École de tennis',
  'Compétition jeunes',
  'Compétition adultes',
  'Tennis loisir',
  'Préparation physique',
  'Tennis adapté'
];

export function LeaderForm({ leader, onSubmit, onCancel }: LeaderFormProps) {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting }
  } = useForm({
    defaultValues: leader || {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      role: 'coach' as LeaderRole,
      specialties: [],
      active: true
    }
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <Input
          label="Prénom"
          {...register('firstName', { required: 'Le prénom est requis' })}
          error={errors.firstName?.message}
        />
        <Input
          label="Nom"
          {...register('lastName', { required: 'Le nom est requis' })}
          error={errors.lastName?.message}
        />
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <Input
          label="Email"
          type="email"
          {...register('email', {
            required: 'L\'email est requis',
            pattern: {
              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
              message: 'Email invalide'
            }
          })}
          error={errors.email?.message}
        />
        <Input
          label="Téléphone"
          {...register('phone', {
            pattern: {
              value: /^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$/,
              message: 'Numéro de téléphone invalide'
            }
          })}
          error={errors.phone?.message}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Rôle</label>
        <select
          {...register('role', { required: 'Le rôle est requis' })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
        >
          {ROLE_OPTIONS.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        {errors.role && (
          <p className="mt-1 text-sm text-red-600">{errors.role.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Spécialités
        </label>
        <div className="space-y-2">
          {SPECIALTIES.map(specialty => (
            <label key={specialty} className="flex items-center">
              <input
                type="checkbox"
                value={specialty}
                {...register('specialties')}
                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <span className="ml-2 text-sm text-gray-700">{specialty}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="flex items-center">
          <input
            type="checkbox"
            {...register('active')}
            className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
          />
          <span className="ml-2 text-sm text-gray-700">Leader actif</span>
        </label>
      </div>

      <div className="flex justify-end space-x-3">
        <Button type="button" variant="secondary" onClick={onCancel}>
          Annuler
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {leader ? 'Mettre à jour' : 'Créer'} le leader
        </Button>
      </div>
    </form>
  );
}