import React, { useState } from 'react';
import { Edit2, Trash2 } from 'lucide-react';
import { calculateAge, formatDate } from '../utils/dateUtils';
import type { Member, TimeSlot } from '../types/member';

interface MemberListProps {
  members: Member[];
  onEdit: (member: Member) => void;
  onDelete: (member: Member) => void;
  onSelectionChange?: (selectedMembers: Member[]) => void;
}

function formatTimeSlot(timeSlot: TimeSlot): string {
  return `${timeSlot.hour.toString().padStart(2, '0')}:${timeSlot.minute.toString().padStart(2, '0')}`;
}

function formatAvailability(member: Member): string {
  const availableDays = Object.entries(member.availability)
    .filter(([_, value]) => value.available && value.timeSlots.length > 0)
    .map(([day, value]) => {
      const times = value.timeSlots.map(formatTimeSlot).join(', ');
      return `${day.slice(0, 3)}: ${times}`;
    });
  return availableDays.join(' | ');
}

export function MemberList({ members, onEdit, onDelete, onSelectionChange }: MemberListProps) {
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());

  const handleSelectAll = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      setSelectedRows(new Set(members.map(m => m.id)));
    } else {
      setSelectedRows(new Set());
    }
    onSelectionChange?.(event.target.checked ? members : []);
  };

  const handleSelectRow = (event: React.ChangeEvent<HTMLInputElement>, member: Member) => {
    const newSelected = new Set(selectedRows);
    if (event.target.checked) {
      newSelected.add(member.id);
    } else {
      newSelected.delete(member.id);
    }
    setSelectedRows(newSelected);
    onSelectionChange?.(members.filter(m => newSelected.has(m.id)));
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left">
              <input
                type="checkbox"
                onChange={handleSelectAll}
                checked={selectedRows.size === members.length}
                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Nom
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Sexe
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Date de naissance
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Niveau
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Séances/Semaine
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Disponibilités
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {members.map((member) => (
            <tr key={member.id} className={selectedRows.has(member.id) ? 'bg-indigo-50' : undefined}>
              <td className="px-6 py-4">
                <input
                  type="checkbox"
                  checked={selectedRows.has(member.id)}
                  onChange={(e) => handleSelectRow(e, member)}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-gray-900">
                  {member.firstName} {member.lastName}
                </div>
                <div className="text-sm text-gray-500">{member.email}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                  member.gender === 'homme' ? 'bg-blue-100 text-blue-800' : 'bg-pink-100 text-pink-800'
                }`}>
                  {member.gender === 'homme' ? 'Homme' : 'Femme'}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{formatDate(member.birthDate)}</div>
                <div className="text-xs text-gray-500">
                  {calculateAge(member.birthDate)} ans ({member.ageCategory})
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{member.skillLevel}</div>
                <div className="text-xs text-gray-500">{member.generalLevel}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {member.sessionsPerWeek}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {formatAvailability(member)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button
                  onClick={() => onEdit(member)}
                  className="text-indigo-600 hover:text-indigo-900 mr-4"
                >
                  <Edit2 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => onDelete(member)}
                  className="text-red-600 hover:text-red-900"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}