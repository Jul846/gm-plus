import React from 'react';
import { useForm } from 'react-hook-form';
import { Input } from './Input';
import { Button } from './Button';
import { TimeSlotPicker } from './TimeSlotPicker';
import { 
  GENERAL_LEVELS, 
  GENERAL_LEVEL_LABELS, 
  FFT_ADULT_LEVELS, 
  FFT_KID_LEVELS, 
  GALAXIE_LEVELS, 
  GALAXIE_LEVEL_LABELS 
} from '../utils/tennisLevels';
import { calculateAge, determineAgeCategory, getMaxBirthDate, getMinBirthDate } from '../utils/dateUtils';
import { useConfigStore } from '../store/configStore';
import type { Member, TimeSlot, Gender } from '../types/member';

interface MemberFormProps {
  member?: Member;
  onSubmit: (data: Partial<Member>) => Promise<void>;
  onCancel: () => void;
}

const DAYS = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];

const GENDER_OPTIONS: { value: Gender; label: string }[] = [
  { value: 'homme', label: 'Homme' },
  { value: 'femme', label: 'Femme' },
];

export function MemberForm({ member, onSubmit, onCancel }: MemberFormProps) {
  const { config } = useConfigStore();
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm({
    defaultValues: member || {
      firstName: '',
      lastName: '',
      email: '',
      gender: 'homme' as Gender,
      birthDate: new Date().toISOString().split('T')[0],
      ageCategory: 'adulte',
      skillLevel: 'NC',
      generalLevel: 'DEBUTANT',
      hasFFTRanking: false,
      sessionsPerWeek: 1,
      availability: DAYS.reduce((acc, day) => ({
        ...acc,
        [day]: {
          available: false,
          timeSlots: [],
        },
      }), {}),
    },
  });

  const watchBirthDate = watch('birthDate');
  const kidMaxAge = config?.ageCategories.kidMaxAge || 18;

  React.useEffect(() => {
    if (watchBirthDate) {
      const age = calculateAge(watchBirthDate);
      const category = determineAgeCategory(watchBirthDate, kidMaxAge);
      setValue('ageCategory', category);
      
      // Réinitialiser le niveau si nécessaire
      if (category === 'enfant' && !GALAXIE_LEVELS.includes(watch('skillLevel') as any)) {
        setValue('skillLevel', 'GALAXIE_BLANC');
      } else if (category === 'adulte' && !FFT_ADULT_LEVELS.includes(watch('skillLevel') as any)) {
        setValue('skillLevel', 'NC');
      }
    }
  }, [watchBirthDate, setValue, kidMaxAge]);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <Input
          label="Prénom"
          {...register('firstName', { required: 'Le prénom est requis' })}
          error={errors.firstName?.message}
        />
        <Input
          label="Nom"
          {...register('lastName', { required: 'Le nom est requis' })}
          error={errors.lastName?.message}
        />
      </div>

      <Input
        label="Email"
        type="email"
        {...register('email', {
          required: 'L\'email est requis',
          pattern: {
            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
            message: 'Adresse email invalide',
          },
        })}
        error={errors.email?.message}
      />

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div>
          <label className="block text-sm font-medium text-gray-700">Sexe</label>
          <select
            {...register('gender', { required: 'Le sexe est requis' })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          >
            {GENDER_OPTIONS.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          {errors.gender && (
            <p className="mt-1 text-sm text-red-600">{errors.gender.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Date de naissance
          </label>
          <Input
            type="date"
            min={getMinBirthDate()}
            max={getMaxBirthDate()}
            {...register('birthDate', {
              required: 'La date de naissance est requise',
              validate: {
                notFuture: (value) => new Date(value) <= new Date() || 'La date ne peut pas être dans le futur',
                notTooOld: (value) => new Date(value) >= new Date(getMinBirthDate()) || 'L\'âge maximum est de 99 ans',
                notTooYoung: (value) => new Date(value) <= new Date(getMaxBirthDate()) || 'L\'âge minimum est de 4 ans',
              },
            })}
            error={errors.birthDate?.message}
          />
          {watchBirthDate && (
            <p className="mt-1 text-sm text-gray-500">
              Âge: {calculateAge(watchBirthDate)} ans ({determineAgeCategory(watchBirthDate, kidMaxAge)})
            </p>
          )}
        </div>
      </div>

      {/* Reste du formulaire inchangé */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div>
          <label className="block text-sm font-medium text-gray-700">Niveau général</label>
          <select
            {...register('generalLevel')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          >
            {GENERAL_LEVELS.map(level => (
              <option key={level} value={level}>
                {GENERAL_LEVEL_LABELS[level]}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Classement FFT</label>
          <div className="flex items-center space-x-2 mb-2">
            <input
              type="checkbox"
              {...register('hasFFTRanking')}
              className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
            />
            <span className="text-sm">A un classement FFT</span>
          </div>
          {watch('hasFFTRanking') && (
            <select
              {...register('skillLevel')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            >
              {watch('ageCategory') === 'enfant' ? (
                <>
                  {GALAXIE_LEVELS.map(level => (
                    <option key={level} value={level}>
                      {GALAXIE_LEVEL_LABELS[level]}
                    </option>
                  ))}
                  {FFT_KID_LEVELS.map(level => (
                    <option key={level} value={level}>{level}</option>
                  ))}
                </>
              ) : (
                FFT_ADULT_LEVELS.map(level => (
                  <option key={level} value={level}>{level}</option>
                ))
              )}
            </select>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Séances par semaine</label>
        <Input
          type="number"
          min={1}
          max={7}
          {...register('sessionsPerWeek', {
            required: 'Le nombre de séances est requis',
            min: { value: 1, message: 'Minimum 1 séance par semaine' },
            max: { value: 7, message: 'Maximum 7 séances par semaine' },
          })}
          error={errors.sessionsPerWeek?.message}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Disponibilités</label>
        <div className="space-y-4">
          {DAYS.map((day) => (
            <div key={day} className="space-y-2">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  {...register(`availability.${day}.available`)}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-sm capitalize">{day}</span>
              </div>
              {watch(`availability.${day}.available`) && (
                <TimeSlotPicker
                  value={watch(`availability.${day}.timeSlots`) || []}
                  onChange={(timeSlots: TimeSlot[]) => 
                    setValue(`availability.${day}.timeSlots`, timeSlots)
                  }
                />
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end space-x-3">
        <Button type="button" variant="secondary" onClick={onCancel}>
          Annuler
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {member ? 'Mettre à jour' : 'Créer'} le membre
        </Button>
      </div>
    </form>
  );
}