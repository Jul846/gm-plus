import React from 'react';
import { Link } from 'react-router-dom';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white border-t">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase mb-4">
              À propos
            </h3>
            <p className="text-base text-gray-600">
              GM+ est une application de gestion de groupes homogènes pour le tennis,
              permettant d'optimiser la formation des groupes selon divers critères.
            </p>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase mb-4">
              Liens légaux
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/legal/terms" className="text-gray-600 hover:text-gray-900">
                  Conditions d'utilisation
                </Link>
              </li>
              <li>
                <Link to="/legal/privacy" className="text-gray-600 hover:text-gray-900">
                  Politique de confidentialité
                </Link>
              </li>
              <li>
                <Link to="/legal/gdpr" className="text-gray-600 hover:text-gray-900">
                  RGPD
                </Link>
              </li>
              <li>
                <Link to="/legal/mentions" className="text-gray-600 hover:text-gray-900">
                  Mentions légales
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase mb-4">
              Contact
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/contact" className="text-gray-600 hover:text-gray-900">
                  Formulaire de contact
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 border-t border-gray-200 pt-8">
          <p className="text-center text-sm text-gray-500">
            &copy; {currentYear} GM+. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
}