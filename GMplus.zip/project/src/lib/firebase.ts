import { initializeApp } from 'firebase/app';
import { getAuth, browserLocalPersistence, setPersistence } from 'firebase/auth';
import { getFirestore, enableMultiTabIndexedDbPersistence } from 'firebase/firestore';
import { toast } from 'react-toastify';

const firebaseConfig = {
  apiKey: "AIzaSyAk6ziiKnyfE7LvWcASDKUNxm11eIxJGvQ",
  authDomain: "gmwebapp-3dbc3.firebaseapp.com",
  projectId: "gmwebapp-3dbc3",
  storageBucket: "gmwebapp-3dbc3.firebasestorage.app",
  messagingSenderId: "92559022098",
  appId: "1:92559022098:web:b4021653f82a7dc46520cb"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Enable offline persistence
enableMultiTabIndexedDbPersistence(db).catch((err) => {
  if (err.code === 'failed-precondition') {
    toast.warning('La persistance hors ligne est limitée à un seul onglet à la fois');
  } else if (err.code === 'unimplemented') {
    toast.warning('Votre navigateur ne supporte pas la persistance hors ligne');
  }
});

// Set persistence to LOCAL
setPersistence(auth, browserLocalPersistence).catch((error) => {
  console.error('Firebase persistence error:', error);
  toast.error('Erreur de configuration de l\'authentification');
});

// Set language to French
auth.languageCode = 'fr';

export { auth, db };