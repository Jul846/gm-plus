import { collection, addDoc, updateDoc, deleteDoc, doc, getDocs, query, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import type { Member } from '../types/member';

export const memberService = {
  async createMember(memberData: Omit<Member, 'id' | 'createdAt' | 'updatedAt'>) {
    try {
      const docRef = await addDoc(collection(db, 'members'), {
        ...memberData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      return docRef.id;
    } catch (error) {
      console.error('Error creating member:', error);
      throw error;
    }
  },

  async updateMember(id: string, memberData: Partial<Member>) {
    try {
      const memberRef = doc(db, 'members', id);
      await updateDoc(memberRef, {
        ...memberData,
        updatedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error updating member:', error);
      throw error;
    }
  },

  async deleteMember(id: string) {
    try {
      await deleteDoc(doc(db, 'members', id));
    } catch (error) {
      console.error('Error deleting member:', error);
      throw error;
    }
  },

  async getAllMembers() {
    try {
      const querySnapshot = await getDocs(collection(db, 'members'));
      return querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Member[];
    } catch (error) {
      console.error('Error fetching members:', error);
      throw error;
    }
  },

  async getMembersBySkillLevel(skillLevel: string) {
    try {
      const q = query(collection(db, 'members'), where('skillLevel', '==', skillLevel));
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Member[];
    } catch (error) {
      console.error('Error fetching members by skill level:', error);
      throw error;
    }
  }
};