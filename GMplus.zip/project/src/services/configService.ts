import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import type { TennisConfig } from '../types/config';
import { DEFAULT_WEIGHTS } from '../utils/groupUtils';

const CONFIG_DOC_ID = 'tennis_config';

export const defaultConfig: TennisConfig = {
  id: CONFIG_DOC_ID,
  skillLevels: {
    adult: [
      'NC', '40', '30/5', '30/4', '30/3', '30/2', '30/1',
      '15/5', '15/4', '15/3', '15/2', '15/1',
      '4/6', '3/6', '2/6', '1/6', '0', '-2/6', '-4/6', '-15', 'PRO'
    ],
    kid: [
      'GALAXIE_BLANC', 'GALAXIE_VIOLET', 'GALAXIE_ROUGE',
      'GALAXIE_ORANGE', 'GALAXIE_VERT',
      'COMPETITION_11', 'COMPETITION_12', 'COMPETITION_13', 'COMPETITION_14',
      'NC', '40', '30/5', '30/4', '30/3', '30/2', '30/1'
    ],
    general: [
      'DEBUTANT', 'DEBUTANT_PLUS',
      'INTERMEDIAIRE', 'INTERMEDIAIRE_PLUS',
      'AVANCE', 'AVANCE_PLUS'
    ]
  },
  ageCategories: {
    min: 4,
    max: 99,
    kidMaxAge: 18
  },
  timeSlots: {
    minHour: 8,
    maxHour: 22,
    intervals: [0, 15, 30, 45]
  },
  grouping: {
    weights: DEFAULT_WEIGHTS,
    maxSizeDifference: 1,
    minGroupSize: 2,
    maxGroupSize: 8,
    defaultGroupCount: 2,
    defaultMembersPerGroup: 4,
    groupingMode: 'byCount'
  },
  updatedAt: new Date().toISOString(),
  updatedBy: 'system'
};

export const configService = {
  async getConfig(): Promise<TennisConfig> {
    try {
      const docRef = doc(db, 'config', CONFIG_DOC_ID);
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) {
        await setDoc(docRef, defaultConfig);
        return defaultConfig;
      }
      
      return {
        ...defaultConfig, // Utiliser les valeurs par défaut comme base
        ...docSnap.data() // Écraser avec les valeurs personnalisées
      } as TennisConfig;
    } catch (error) {
      console.error('Error getting config:', error);
      return defaultConfig; // Retourner la configuration par défaut en cas d'erreur
    }
  },

  async updateConfig(config: Partial<TennisConfig>, userId: string): Promise<void> {
    try {
      const docRef = doc(db, 'config', CONFIG_DOC_ID);
      await setDoc(docRef, {
        ...config,
        updatedAt: new Date().toISOString(),
        updatedBy: userId
      }, { merge: true });
    } catch (error) {
      console.error('Error updating config:', error);
      throw error;
    }
  }
};