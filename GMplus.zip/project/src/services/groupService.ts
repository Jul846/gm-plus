import { collection, addDoc, updateDoc, deleteDoc, doc, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import type { Group } from '../types/group';
import type { Member } from '../types/member';
import { calculateGroupCompatibilityScore } from '../utils/groupUtils';

interface GroupingOptions {
  mode: 'byCount' | 'bySize';
  value: number;
}

export const groupService = {
  createOptimalGroups(members: Member[], options: GroupingOptions) {
    const { mode, value } = options;
    let numberOfGroups: number;

    if (mode === 'byCount') {
      numberOfGroups = value;
    } else {
      // Mode bySize : calculer le nombre de groupes nécessaire
      numberOfGroups = Math.ceil(members.length / value);
    }

    const groups: Member[][] = Array.from({ length: numberOfGroups }, () => []);
    const remainingMembers = [...members];

    // Distribuer les premiers membres dans chaque groupe
    for (let i = 0; i < numberOfGroups && remainingMembers.length > 0; i++) {
      const member = remainingMembers.pop();
      if (member) groups[i].push(member);
    }

    // Distribuer les membres restants
    while (remainingMembers.length > 0) {
      const member = remainingMembers.pop();
      if (!member) break;

      let bestGroupIndex = 0;
      let bestScore = -1;

      // Trouver le meilleur groupe pour ce membre
      groups.forEach((group, index) => {
        // En mode bySize, ne pas dépasser la taille maximale par groupe
        if (mode === 'bySize' && group.length >= value) return;

        const testGroup = [...group, member];
        const score = calculateGroupCompatibilityScore(testGroup);
        
        if (score > bestScore) {
          bestScore = score;
          bestGroupIndex = index;
        }
      });

      groups[bestGroupIndex].push(member);
    }

    // En mode bySize, créer des groupes supplémentaires si nécessaire
    if (mode === 'bySize') {
      this.balanceGroupsBySize(groups, value);
    } else {
      this.balanceGroups(groups);
    }

    // Supprimer les groupes vides
    return groups.filter(group => group.length > 0);
  },

  balanceGroups(groups: Member[][]) {
    let iterations = 0;
    const maxIterations = 100;
    let improved = true;

    while (improved && iterations < maxIterations) {
      improved = false;
      iterations++;

      for (let i = 0; i < groups.length; i++) {
        for (let j = i + 1; j < groups.length; j++) {
          if (Math.abs(groups[i].length - groups[j].length) > 1) {
            const sourceGroup = groups[i].length > groups[j].length ? i : j;
            const targetGroup = sourceGroup === i ? j : i;

            const member = groups[sourceGroup].pop();
            if (member) {
              groups[targetGroup].push(member);
              improved = true;
            }
          }
        }
      }
    }
  },

  balanceGroupsBySize(groups: Member[][], targetSize: number) {
    let iterations = 0;
    const maxIterations = 100;
    let improved = true;

    while (improved && iterations < maxIterations) {
      improved = false;
      iterations++;

      for (let i = 0; i < groups.length; i++) {
        if (groups[i].length > targetSize) {
          // Chercher un groupe qui peut accueillir plus de membres
          const targetGroupIndex = groups.findIndex(g => g.length < targetSize);
          if (targetGroupIndex !== -1) {
            const member = groups[i].pop();
            if (member) {
              groups[targetGroupIndex].push(member);
              improved = true;
            }
          } else {
            // Créer un nouveau groupe si nécessaire
            const newGroup: Member[] = [];
            const member = groups[i].pop();
            if (member) {
              newGroup.push(member);
              groups.push(newGroup);
              improved = true;
            }
          }
        }
      }
    }
  }
};