import React from 'react';
import { Settings, RotateCcw } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { useConfigStore } from '../store/configStore';
import { useAuthStore } from '../store/authStore';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { toast } from 'react-toastify';

export function AdminConfig() {
  const { user, role } = useAuthStore();
  const { config, isLoading, error, updateConfig, resetConfig, fetchConfig } = useConfigStore();
  const { register, handleSubmit, reset } = useForm();

  React.useEffect(() => {
    fetchConfig();
  }, [fetchConfig]);

  React.useEffect(() => {
    if (config) {
      reset(config);
    }
  }, [config, reset]);

  if (!user || !['admin', 'superadmin', 'supreme'].includes(role || '')) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-semibold text-gray-900">Accès Refusé</h2>
        <p className="mt-2 text-gray-600">
          Vous n'avez pas les permissions nécessaires pour accéder à cette page.
        </p>
      </div>
    );
  }

  const onSubmit = async (data: any) => {
    try {
      await updateConfig(data, user.uid);
      toast.success('Configuration mise à jour avec succès');
    } catch (error) {
      toast.error('Erreur lors de la mise à jour de la configuration');
    }
  };

  const handleReset = async () => {
    if (window.confirm('Êtes-vous sûr de vouloir réinitialiser la configuration ?')) {
      try {
        await resetConfig(user.uid);
        toast.success('Configuration réinitialisée avec succès');
      } catch (error) {
        toast.error('Erreur lors de la réinitialisation');
      }
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600">{error}</p>
        <Button onClick={() => fetchConfig()} className="mt-4">
          Réessayer
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900 flex items-center">
          <Settings className="h-6 w-6 mr-2" />
          Configuration du système
        </h1>
        <Button onClick={handleReset} variant="secondary" className="flex items-center">
          <RotateCcw className="h-4 w-4 mr-2" />
          Réinitialiser
        </Button>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        {/* Critères d'âge */}
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Critères d'âge</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Input
              label="Âge minimum"
              type="number"
              {...register('ageCategories.min')}
            />
            <Input
              label="Âge maximum"
              type="number"
              {...register('ageCategories.max')}
            />
            <Input
              label="Âge maximum enfant"
              type="number"
              {...register('ageCategories.kidMaxAge')}
            />
          </div>
        </div>

        {/* Pondération des critères */}
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Pondération des critères</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Input
              label="Niveau (0-1)"
              type="number"
              step="0.1"
              min="0"
              max="1"
              {...register('grouping.weights.skillLevel')}
            />
            <Input
              label="Présence (0-1)"
              type="number"
              step="0.1"
              min="0"
              max="1"
              {...register('grouping.weights.attendance')}
            />
            <Input
              label="Disponibilité (0-1)"
              type="number"
              step="0.1"
              min="0"
              max="1"
              {...register('grouping.weights.availability')}
            />
            <Input
              label="Âge (0-1)"
              type="number"
              step="0.1"
              min="0"
              max="1"
              {...register('grouping.weights.age')}
            />
            <Input
              label="Genre (0-1)"
              type="number"
              step="0.1"
              min="0"
              max="1"
              {...register('grouping.weights.gender')}
            />
          </div>
        </div>

        {/* Horaires */}
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Plages horaires</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input
              label="Heure minimum"
              type="number"
              min="0"
              max="23"
              {...register('timeSlots.minHour')}
            />
            <Input
              label="Heure maximum"
              type="number"
              min="1"
              max="24"
              {...register('timeSlots.maxHour')}
            />
          </div>
        </div>

        <div className="flex justify-end">
          <Button type="submit" isLoading={isLoading}>
            Enregistrer les modifications
          </Button>
        </div>
      </form>
    </div>
  );
}