import React from 'react';
import { Link } from 'react-router-dom';
import { Users, UserPlus, BarChart } from 'lucide-react';

export function Home() {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center bg-gradient-to-br from-indigo-50 to-white">
      <div className="text-center max-w-3xl mx-auto px-4">
        <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
          Créez des Groupes Intelligents
          <span className="text-indigo-600"> Facilement</span>
        </h1>
        <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg md:mt-5 md:text-xl">
          Formez des groupes homogènes basés sur les niveaux de compétence, les rythmes de présence et les disponibilités.
          Parfait pour organiser des équipes, des classes ou toute activité de groupe.
        </p>
        <div className="mt-10">
          <Link
            to="/register"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
          >
            Commencer
          </Link>
        </div>
      </div>

      <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 max-w-7xl mx-auto px-4">
        <div className="relative bg-white p-6 rounded-lg shadow-md">
          <div className="absolute -top-4 left-4 bg-indigo-600 rounded-full p-3">
            <Users className="h-6 w-6 text-white" />
          </div>
          <h3 className="mt-4 text-lg font-medium text-gray-900">Gestion des Membres</h3>
          <p className="mt-2 text-gray-500">
            Gérez facilement les membres avec des profils détaillés incluant niveaux et disponibilités.
          </p>
        </div>

        <div className="relative bg-white p-6 rounded-lg shadow-md">
          <div className="absolute -top-4 left-4 bg-indigo-600 rounded-full p-3">
            <UserPlus className="h-6 w-6 text-white" />
          </div>
          <h3 className="mt-4 text-lg font-medium text-gray-900">Groupage Intelligent</h3>
          <p className="mt-2 text-gray-500">
            Algorithme intelligent créant des groupes équilibrés selon plusieurs critères.
          </p>
        </div>

        <div className="relative bg-white p-6 rounded-lg shadow-md">
          <div className="absolute -top-4 left-4 bg-indigo-600 rounded-full p-3">
            <BarChart className="h-6 w-6 text-white" />
          </div>
          <h3 className="mt-4 text-lg font-medium text-gray-900">Analytique</h3>
          <p className="mt-2 text-gray-500">
            Rapports complets et visualisations des compositions et métriques des groupes.
          </p>
        </div>
      </div>
    </div>
  );
}