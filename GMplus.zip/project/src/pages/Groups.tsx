import React, { useState, useEffect } from 'react';
import { Users, Settings } from 'lucide-react';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { GroupList } from '../components/GroupList';
import { GroupSettings } from '../components/GroupSettings';
import { ExportGroupButtons } from '../components/ExportGroupButtons';
import { useMemberStore } from '../store/memberStore';
import { useGroupStore } from '../store/groupStore';
import { useConfigStore } from '../store/configStore';
import { toast } from 'react-toastify';

export function Groups() {
  const { members, fetchMembers } = useMemberStore();
  const { generateGroups, currentGroups } = useGroupStore();
  const { config } = useConfigStore();
  const [showSettings, setShowSettings] = useState(false);
  const [groupingMode, setGroupingMode] = useState<'byCount' | 'bySize'>(
    config?.grouping.groupingMode || 'byCount'
  );
  const [groupValue, setGroupValue] = useState(
    groupingMode === 'byCount' 
      ? config?.grouping.defaultGroupCount || 2
      : config?.grouping.defaultMembersPerGroup || 4
  );

  useEffect(() => {
    fetchMembers();
  }, [fetchMembers]);

  const handleGenerateGroups = () => {
    if (members.length === 0) {
      toast.warning('Aucun membre disponible pour créer des groupes');
      return;
    }

    if (groupingMode === 'byCount' && groupValue > members.length) {
      toast.warning('Le nombre de groupes ne peut pas dépasser le nombre de membres');
      return;
    }

    if (groupingMode === 'bySize' && groupValue > members.length) {
      toast.warning('La taille des groupes ne peut pas dépasser le nombre total de membres');
      return;
    }

    try {
      generateGroups(members, { mode: groupingMode, value: groupValue });
      toast.success('Groupes générés avec succès');
    } catch (error) {
      console.error('Error generating groups:', error);
      toast.error('Erreur lors de la génération des groupes');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Groupes</h1>
        <div className="flex items-center space-x-4">
          {currentGroups && currentGroups.length > 0 && (
            <ExportGroupButtons groups={currentGroups} />
          )}

          <div className="flex items-center space-x-4">
            <select
              value={groupingMode}
              onChange={(e) => {
                setGroupingMode(e.target.value as 'byCount' | 'bySize');
                setGroupValue(
                  e.target.value === 'byCount'
                    ? config?.grouping.defaultGroupCount || 2
                    : config?.grouping.defaultMembersPerGroup || 4
                );
              }}
              className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            >
              <option value="byCount">Par nombre de groupes</option>
              <option value="bySize">Par taille de groupe</option>
            </select>

            <Input
              type="number"
              min={2}
              max={members.length}
              value={groupValue}
              onChange={(e) => setGroupValue(Math.max(2, Math.min(members.length, parseInt(e.target.value))))}
              className="w-24"
              label={groupingMode === 'byCount' ? 'Nombre de groupes' : 'Membres par groupe'}
            />

            <Button onClick={handleGenerateGroups} className="flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Générer les groupes
            </Button>

            <Button
              variant="secondary"
              onClick={() => setShowSettings(true)}
              className="flex items-center"
            >
              <Settings className="h-4 w-4 mr-2" />
              Paramètres
            </Button>
          </div>
        </div>
      </div>

      {showSettings && (
        <GroupSettings onClose={() => setShowSettings(false)} />
      )}

      {currentGroups && currentGroups.length > 0 ? (
        <GroupList groups={currentGroups} />
      ) : (
        <div className="bg-white shadow rounded-lg p-6 text-center">
          <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun groupe généré</h3>
          <p className="text-gray-500">
            Cliquez sur le bouton "Générer les groupes" pour créer des groupes homogènes basés sur les critères des membres.
          </p>
        </div>
      )}
    </div>
  );
}