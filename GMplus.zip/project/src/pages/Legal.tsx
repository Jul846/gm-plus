import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

const LEGAL_CONTENT = {
  terms: {
    title: "Conditions Générales d'Utilisation",
    content: `
### Conditions Générales d'Utilisation de GM+
Version applicable au 19/11/2024

1. Objet
Les présentes CGU régissent l'utilisation de l'application GM+, service de gestion de groupes de tennis destiné aux entraîneurs dans le cadre d'une collaboration et d'un management de joueurs et d'entraîneurs dans un club de tennis.

2. Accès au service
L'accès à l'application nécessite une inscription préalable. L'utilisateur s'engage à fournir des informations exactes.

3. Utilisation du service
L'utilisateur s'engage à utiliser l'application conformément à sa destination et à ne pas porter atteinte aux droits des tiers.

4. Responsabilités
L'application est fournie "en l'état". Nous ne garantissons pas son fonctionnement ininterrompu ou exempt d'erreurs.

5. Données personnelles
Le traitement des données personnelles est soumis à notre politique de confidentialité, conformément au RGPD.

6. Modification
Nous nous réservons le droit de modifier ces CGU à tout moment. Les utilisateurs seront informés des modifications substantielles.`
  },
  privacy: {
    title: "Politique de Confidentialité",
    content: `
### Politique de Confidentialité de GM+
Version applicable au 19/11/2024

1. Responsable du traitement
GM+, représenté par :
Frate Solutions SAS
Email : contact@frateme.com
DPO : contact@frateme.com

2. Données collectées
Nous collectons et traitons les données suivantes :
- Données d'identification : nom, prénom, email
- Données sportives : niveau, catégorie, classement FFT
- Données de disponibilité : créneaux horaires, préférences
- Données de connexion : logs, adresse IP

3. Finalités du traitement
Vos données sont utilisées pour :
- La gestion de votre compte utilisateur
- L'organisation et l'optimisation des groupes de tennis
- La communication relative aux activités sportives
- L'amélioration de nos services

4. Base légale
- Exécution du contrat pour la gestion de votre compte
- Consentement pour les communications
- Intérêt légitime pour l'amélioration des services

5. Durée de conservation
Vos données sont conservées :
- Données de compte : pendant la durée d'utilisation du service
- Données sportives : 3 ans après la dernière activité
- Logs de connexion : 1 an

6. Destinataires des données
Vos données sont accessibles :
- Au personnel autorisé de GM+
- Aux sous-traitants techniques (hébergement, maintenance)

7. Sécurité
Nous mettons en œuvre des mesures techniques et organisationnelles pour protéger vos données :
- Chiffrement des données
- Accès restreint aux personnes habilitées
- Sauvegarde régulière

8. Vos droits
Conformément au RGPD, vous disposez des droits suivants :
- Accès à vos données
- Rectification des données inexactes
- Effacement des données
- Portabilité des données
- Opposition au traitement
- Limitation du traitement

Pour exercer vos droits, contactez notre DPO : contact@frateme.com`
  },
  mentions: {
    title: "Mentions Légales",
    content: `
### Mentions Légales
Dernière mise à jour : 19/11/2024

Éditeur
Frate Solutions SAS
Email : contact@frateme.com

Délégué à la Protection des Données (DPO)
Email : contact@frateme.com

Hébergeur
Netlify, Inc.
44 Montgomery Street, Suite 300
San Francisco, California 94104
support@netlify.com

Propriété intellectuelle
L'ensemble du contenu de ce site est protégé par le droit d'auteur.

Cookies
Ce site utilise uniquement des cookies techniques nécessaires à son fonctionnement. Ces cookies ne collectent pas de données personnelles.`
  },
  gdpr: {
    title: "RGPD",
    content: `
### Politique RGPD
Dernière mise à jour : 19/11/2024

LA SOCIETE EDITRICE attache une grande importance à la protection de la vie privée de ses utilisateurs. Les Données Personnelles des utilisateurs de l'Application GM+ sont traitées dans le respect de la présente Politique de Confidentialité également accessible dans l'application.

En vous inscrivant et en utilisant l'application GM+, vous fournissez et, nous allons recueillir de notre côté, un certain nombre d'informations vous concernant dont certaines sont de nature à vous identifier. C'est ce que l'on appelle vos « Données Personnelles », désignant les données pouvant vous identifier directement, telles que votre nom, prénom ou votre image, ou indirectement, telles que votre mot de passe, adresse email, ou encore vos données de navigation et d'interaction.

QUI EST RESPONSABLE DU TRAITEMENT DE VOS DONNÉES PERSONNELLES?
C'est la SAS FRATE SOLUTIONS. Nous sommes une société française dont le siège social est situé à MONTPELLIER (34070), 1400 rue de La Castelle, immatriculée au RCS de MONTPELLIER.

La SAS FRATE SOLUTIONS est l'éditeur de l'application GM+ qui est une application de gestion de groupes de tennis permettant aux entraîneurs de gérer efficacement leurs groupes d'entraînement.

Pour toute question concernant vos données personnelles, vous pouvez nous contacter :
- Par email : contact@frateme.com
- Par téléphone : 04 99 54 32 30
- Par courrier : FRATE SOLUTIONS SAS, 1400 rue de la Castelle, 34070 MONTPELLIER

Vos droits concernant vos données personnelles :
- Droit d'accès
- Droit de rectification
- Droit à l'effacement
- Droit à la portabilité
- Droit d'opposition
- Droit à la limitation du traitement

Pour exercer ces droits, contactez-nous aux coordonnées indiquées ci-dessus.`
  }
};

export function Legal() {
  const { page = 'terms' } = useParams<{ page: keyof typeof LEGAL_CONTENT }>();
  const content = LEGAL_CONTENT[page as keyof typeof LEGAL_CONTENT];

  if (!content) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-semibold text-gray-900">Page non trouvée</h2>
        <Link to="/" className="text-indigo-600 hover:text-indigo-800 mt-4 inline-block">
          Retour à l'accueil
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <Link
        to="/"
        className="inline-flex items-center text-indigo-600 hover:text-indigo-800 mb-6"
      >
        <ChevronLeft className="h-4 w-4 mr-1" />
        Retour à l'accueil
      </Link>

      <article className="prose prose-indigo max-w-none">
        <h1>{content.title}</h1>
        <div className="whitespace-pre-wrap">
          {content.content}
        </div>
      </article>
    </div>
  );
}