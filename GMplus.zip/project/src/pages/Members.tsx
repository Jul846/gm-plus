import React, { useEffect } from 'react';
import { UserPlus } from 'lucide-react';
import { Button } from '../components/Button';
import { MemberList } from '../components/MemberList';
import { MemberForm } from '../components/MemberForm';
import { ExportImportButtons } from '../components/ExportImportButtons';
import { useMemberStore } from '../store/memberStore';
import type { Member } from '../types/member';
import { toast } from 'react-toastify';

export function Members() {
  const { members, isLoading, error, fetchMembers, addMember, updateMember, deleteMember, importMembers } = useMemberStore();
  const [showForm, setShowForm] = React.useState(false);
  const [selectedMember, setSelectedMember] = React.useState<Member | undefined>();
  const [selectedMembers, setSelectedMembers] = React.useState<Member[]>([]);

  useEffect(() => {
    fetchMembers();
  }, [fetchMembers]);

  const handleSubmit = async (data: Partial<Member>) => {
    try {
      if (selectedMember) {
        await updateMember(selectedMember.id, data);
        toast.success('Membre mis à jour avec succès');
      } else {
        await addMember(data as Omit<Member, 'id' | 'createdAt' | 'updatedAt'>);
        toast.success('Membre ajouté avec succès');
      }
      setShowForm(false);
      setSelectedMember(undefined);
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde du membre');
    }
  };

  const handleEdit = (member: Member) => {
    setSelectedMember(member);
    setShowForm(true);
  };

  const handleDelete = async (member: Member) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer ce membre ?')) {
      try {
        await deleteMember(member.id);
        toast.success('Membre supprimé avec succès');
      } catch (error) {
        toast.error('Erreur lors de la suppression du membre');
      }
    }
  };

  const handleImport = async (importedMembers: Partial<Member>[]) => {
    try {
      await importMembers(importedMembers);
      toast.success(`${importedMembers.length} membres importés avec succès`);
    } catch (error) {
      toast.error('Erreur lors de l\'import des membres');
    }
  };

  const handleSelectionChange = (members: Member[]) => {
    setSelectedMembers(members);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600">{error}</p>
        <Button onClick={() => fetchMembers()} className="mt-4">
          Réessayer
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Membres</h1>
        <div className="flex items-center space-x-4">
          <ExportImportButtons
            members={members}
            onImport={handleImport}
            selectedMembers={selectedMembers.length > 0 ? selectedMembers : undefined}
          />
          <Button onClick={() => setShowForm(true)} className="flex items-center">
            <UserPlus className="h-4 w-4 mr-2" />
            Ajouter un membre
          </Button>
        </div>
      </div>

      {showForm ? (
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-6">
            {selectedMember ? 'Modifier' : 'Ajouter'} un membre
          </h2>
          <MemberForm
            member={selectedMember}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setSelectedMember(undefined);
            }}
          />
        </div>
      ) : (
        <div className="bg-white shadow rounded-lg">
          <MemberList
            members={members}
            onEdit={handleEdit}
            onDelete={handleDelete}
            onSelectionChange={handleSelectionChange}
          />
        </div>
      )}
    </div>
  );
}