import React from 'react';
import { useForm } from 'react-hook-form';
import { Mail, Phone, MapPin } from 'lucide-react';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { toast } from 'react-toastify';

interface ContactForm {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export function Contact() {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting }
  } = useForm<ContactForm>();

  const onSubmit = async (data: ContactForm) => {
    try {
      // Ici, vous pouvez implémenter l'envoi réel du message
      console.log('Message envoyé:', data);
      toast.success('Message envoyé avec succès');
      reset();
    } catch (error) {
      toast.error('Erreur lors de l\'envoi du message');
    }
  };

  return (
    <div className="py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900">Contactez-nous</h1>
          <p className="mt-4 text-lg text-gray-600">
            Une question ? N'hésitez pas à nous contacter.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <Input
                label="Nom complet"
                {...register('name', { required: 'Le nom est requis' })}
                error={errors.name?.message}
              />
              
              <Input
                label="Email"
                type="email"
                {...register('email', {
                  required: 'L\'email est requis',
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: 'Email invalide'
                  }
                })}
                error={errors.email?.message}
              />
              
              <Input
                label="Sujet"
                {...register('subject', { required: 'Le sujet est requis' })}
                error={errors.subject?.message}
              />
              
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Message
                </label>
                <textarea
                  {...register('message', { required: 'Le message est requis' })}
                  rows={6}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
                {errors.message && (
                  <p className="mt-1 text-sm text-red-600">{errors.message.message}</p>
                )}
              </div>

              <Button type="submit" className="w-full" isLoading={isSubmitting}>
                Envoyer le message
              </Button>
            </form>
          </div>

          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Informations de contact
              </h2>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <Mail className="h-6 w-6 text-indigo-600 mt-1" />
                  <div className="ml-4">
                    <p className="text-gray-900 font-medium">Email</p>
                    <a href="mailto:contact@frateme.com" className="text-gray-600">
                      contact@frateme.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <Phone className="h-6 w-6 text-indigo-600 mt-1" />
                  <div className="ml-4">
                    <p className="text-gray-900 font-medium">Téléphone</p>
                    <a href="tel:0499543230" className="text-gray-600">
                      04 99 54 32 30
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <MapPin className="h-6 w-6 text-indigo-600 mt-1" />
                  <div className="ml-4">
                    <p className="text-gray-900 font-medium">Adresse</p>
                    <p className="text-gray-600">
                      1400 rue de la Castelle<br />
                      34070 MONTPELLIER<br />
                      France
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Horaires d'ouverture
              </h2>
              <div className="space-y-2">
                <p className="text-gray-600">
                  <span className="font-medium">Lundi - Vendredi:</span> 9h00 - 18h00
                </p>
                <p className="text-gray-600">
                  <span className="font-medium">Samedi:</span> 9h00 - 12h00
                </p>
                <p className="text-gray-600">
                  <span className="font-medium">Dimanche:</span> Fermé
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}