import React, { useState, useEffect } from 'react';
import { collection, getDocs, updateDoc, doc, getDoc } from 'firebase/firestore';
import { BarChart3, Users, UserCheck, Shield, Award } from 'lucide-react';
import { db } from '../lib/firebase';
import { useAuthStore } from '../store/authStore';
import { LeaderList } from '../components/LeaderList';
import { LeaderForm } from '../components/LeaderForm';
import { UserRoleList } from '../components/UserRoleList';
import type { Role } from '../store/authStore';
import type { Member } from '../types/member';
import type { Leader } from '../types/leader';
import { Button } from '../components/Button';
import { toast } from 'react-toastify';

interface User {
  id: string;
  email: string;
  role: Role;
  createdAt: string;
}

interface Stats {
  totalMembers: number;
  totalLeaders: number;
  skillLevels: Record<string, number>;
  attendanceFrequency: Record<string, number>;
}

export function Dashboard() {
  const [users, setUsers] = useState<User[]>([]);
  const [leaders, setLeaders] = useState<Leader[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalMembers: 0,
    totalLeaders: 0,
    skillLevels: {},
    attendanceFrequency: {},
  });
  const [isLoading, setIsLoading] = useState(true);
  const [showLeaderForm, setShowLeaderForm] = useState(false);
  const [selectedLeader, setSelectedLeader] = useState<Leader | null>(null);
  const { role, user } = useAuthStore();

  useEffect(() => {
    if (user && ['admin', 'superadmin', 'supreme'].includes(role || '')) {
      fetchData();
    }
  }, [user, role]);

  const fetchData = async () => {
    try {
      setIsLoading(true);

      // Vérifier d'abord les permissions de l'utilisateur
      const userDoc = await getDoc(doc(db, 'users', user!.uid));
      if (!userDoc.exists() || !['admin', 'superadmin', 'supreme'].includes(userDoc.data().role)) {
        throw new Error('permission-denied');
      }

      // Récupérer les utilisateurs
      const usersSnapshot = await getDocs(collection(db, 'users'));
      const usersData = usersSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as User[];
      setUsers(usersData);

      // Récupérer les leaders
      const leadersSnapshot = await getDocs(collection(db, 'leaders'));
      const leadersData = leadersSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Leader[];
      setLeaders(leadersData);

      // Récupérer les membres pour les statistiques
      const membersSnapshot = await getDocs(collection(db, 'members'));
      const membersData = membersSnapshot.docs.map((doc) => doc.data()) as Member[];
      
      const stats = {
        totalMembers: membersData.length,
        totalLeaders: leadersData.length,
        skillLevels: membersData.reduce((acc, member) => {
          acc[member.skillLevel] = (acc[member.skillLevel] || 0) + 1;
          return acc;
        }, {} as Record<string, number>),
        attendanceFrequency: membersData.reduce((acc, member) => {
          acc[member.sessionsPerWeek] = (acc[member.sessionsPerWeek] || 0) + 1;
          return acc;
        }, {} as Record<string, number>),
      };
      setStats(stats);
    } catch (error: any) {
      console.error('Error fetching dashboard data:', error);
      if (error.code === 'permission-denied' || error.message === 'permission-denied') {
        toast.error('Accès refusé. Vous n\'avez pas les permissions nécessaires.');
      } else {
        toast.error('Erreur lors du chargement des données');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleLeaderSubmit = async (leaderData: Partial<Leader>) => {
    try {
      if (selectedLeader) {
        await updateDoc(doc(db, 'leaders', selectedLeader.id), {
          ...leaderData,
          updatedAt: new Date().toISOString()
        });
        toast.success('Leader mis à jour avec succès');
      } else {
        const docRef = await addDoc(collection(db, 'leaders'), {
          ...leaderData,
          active: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        toast.success('Leader ajouté avec succès');
      }
      await fetchData();
      setShowLeaderForm(false);
      setSelectedLeader(null);
    } catch (error) {
      console.error('Error saving leader:', error);
      toast.error('Erreur lors de la sauvegarde du leader');
    }
  };

  const handleUpdateUserRole = async (userId: string, newRole: Role) => {
    if (role !== 'supreme') {
      toast.error('Seul un super administrateur peut modifier les rôles');
      return;
    }

    try {
      await updateDoc(doc(db, 'users', userId), {
        role: newRole,
        updatedAt: new Date().toISOString()
      });
      toast.success('Rôle mis à jour avec succès');
      await fetchData();
    } catch (error) {
      console.error('Error updating user role:', error);
      toast.error('Erreur lors de la mise à jour du rôle');
    }
  };

  if (!user || !['admin', 'superadmin', 'supreme'].includes(role || '')) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-semibold text-gray-900">Accès Refusé</h2>
        <p className="mt-2 text-gray-600">
          Vous n'avez pas les permissions nécessaires pour accéder à cette page.
        </p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Tableau de bord</h1>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-indigo-100 text-indigo-600">
              <Users className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-gray-900">Total Membres</h3>
              <p className="text-2xl font-semibold text-indigo-600">{stats.totalMembers}</p>
            </div>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-green-100 text-green-600">
              <Award className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-gray-900">Total Leaders</h3>
              <p className="text-2xl font-semibold text-green-600">{stats.totalLeaders}</p>
            </div>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-purple-100 text-purple-600">
              <Shield className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-gray-900">Niveau d'Accès</h3>
              <p className="text-2xl font-semibold text-purple-600 capitalize">{role}</p>
            </div>
          </div>
        </div>
      </div>

      {role === 'supreme' && (
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <UserCheck className="h-5 w-5 mr-2 text-indigo-600" />
              Gestion des Utilisateurs
            </h3>
          </div>
          <UserRoleList users={users} onUpdateRole={handleUpdateUserRole} />
        </div>
      )}

      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-900 flex items-center">
            <Award className="h-5 w-5 mr-2 text-indigo-600" />
            Leaders
          </h3>
          <Button
            onClick={() => {
              setSelectedLeader(null);
              setShowLeaderForm(true);
            }}
            className="flex items-center"
          >
            Ajouter un leader
          </Button>
        </div>
        
        {showLeaderForm ? (
          <div className="p-6">
            <LeaderForm
              leader={selectedLeader}
              onSubmit={handleLeaderSubmit}
              onCancel={() => {
                setShowLeaderForm(false);
                setSelectedLeader(null);
              }}
            />
          </div>
        ) : (
          <LeaderList
            leaders={leaders}
            onEdit={(leader) => {
              setSelectedLeader(leader);
              setShowLeaderForm(true);
            }}
          />
        )}
      </div>
    </div>
  );
}