import { create } from 'zustand';
import { configService, defaultConfig } from '../services/configService';
import type { ConfigState, TennisConfig } from '../types/config';

export const useConfigStore = create<ConfigState & {
  fetchConfig: () => Promise<void>;
  updateConfig: (config: Partial<TennisConfig>, userId: string) => Promise<void>;
  resetConfig: (userId: string) => Promise<void>;
}>((set) => ({
  config: null,
  isLoading: false,
  error: null,

  fetchConfig: async () => {
    set({ isLoading: true, error: null });
    try {
      const config = await configService.getConfig();
      set({ config, isLoading: false });
    } catch (error) {
      set({ error: 'Erreur lors du chargement de la configuration', isLoading: false });
    }
  },

  updateConfig: async (configUpdate, userId) => {
    set({ isLoading: true, error: null });
    try {
      await configService.updateConfig(configUpdate, userId);
      const config = await configService.getConfig();
      set({ config, isLoading: false });
    } catch (error) {
      set({ error: 'Erreur lors de la mise à jour de la configuration', isLoading: false });
    }
  },

  resetConfig: async (userId) => {
    set({ isLoading: true, error: null });
    try {
      await configService.updateConfig(defaultConfig, userId);
      set({ config: defaultConfig, isLoading: false });
    } catch (error) {
      set({ error: 'Erreur lors de la réinitialisation de la configuration', isLoading: false });
    }
  }
}));