import { create } from 'zustand';
import type { Member } from '../types/member';
import { memberService } from '../services/memberService';

interface MemberState {
  members: Member[];
  isLoading: boolean;
  error: string | null;
  fetchMembers: () => Promise<void>;
  addMember: (member: Omit<Member, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateMember: (id: string, member: Partial<Member>) => Promise<void>;
  deleteMember: (id: string) => Promise<void>;
  importMembers: (members: Partial<Member>[]) => Promise<void>;
}

export const useMemberStore = create<MemberState>((set, get) => ({
  members: [],
  isLoading: false,
  error: null,

  fetchMembers: async () => {
    set({ isLoading: true, error: null });
    try {
      const members = await memberService.getAllMembers();
      set({ members, isLoading: false });
    } catch (error) {
      set({ error: 'Erreur lors du chargement des membres', isLoading: false });
    }
  },

  addMember: async (memberData) => {
    set({ isLoading: true, error: null });
    try {
      await memberService.createMember(memberData);
      await get().fetchMembers();
    } catch (error) {
      set({ error: 'Erreur lors de l\'ajout du membre', isLoading: false });
      throw error;
    }
  },

  updateMember: async (id, memberData) => {
    set({ isLoading: true, error: null });
    try {
      await memberService.updateMember(id, memberData);
      await get().fetchMembers();
    } catch (error) {
      set({ error: 'Erreur lors de la mise à jour du membre', isLoading: false });
      throw error;
    }
  },

  deleteMember: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await memberService.deleteMember(id);
      await get().fetchMembers();
    } catch (error) {
      set({ error: 'Erreur lors de la suppression du membre', isLoading: false });
      throw error;
    }
  },

  importMembers: async (members) => {
    set({ isLoading: true, error: null });
    try {
      for (const member of members) {
        await memberService.createMember(member as Omit<Member, 'id' | 'createdAt' | 'updatedAt'>);
      }
      await get().fetchMembers();
    } catch (error) {
      set({ error: 'Erreur lors de l\'import des membres', isLoading: false });
      throw error;
    }
  },
}));