import { create } from 'zustand';
import type { Group, GroupMemberComment } from '../types/group';
import type { Member } from '../types/member';
import { groupService } from '../services/groupService';

interface GroupState {
  groups: Group[];
  currentGroups: Member[][];
  isLoading: boolean;
  error: string | null;
  generateGroups: (members: Member[], options: { mode: 'byCount' | 'bySize'; value: number }) => void;
  updateGroupComment: (groupIndex: number, comment: string, userId: string) => Promise<void>;
  updateMemberComment: (groupIndex: number, memberId: string, comment: string, userId: string) => Promise<void>;
}

export const useGroupStore = create<GroupState>((set, get) => ({
  groups: [],
  currentGroups: [],
  isLoading: false,
  error: null,

  generateGroups: (members, options) => {
    const generatedGroups = groupService.createOptimalGroups(members, options);
    const groups: Group[] = generatedGroups.map((members, index) => ({
      id: `group-${index}`,
      name: `Groupe ${index + 1}`,
      members: members.map(m => m.id),
      memberComments: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      updatedBy: 'system'
    }));
    
    set({ currentGroups: generatedGroups, groups });
  },

  updateGroupComment: async (groupIndex: number, comment: string, userId: string) => {
    const { groups } = get();
    const updatedGroups = [...groups];
    if (updatedGroups[groupIndex]) {
      updatedGroups[groupIndex] = {
        ...updatedGroups[groupIndex],
        groupComment: comment,
        updatedAt: new Date().toISOString(),
        updatedBy: userId
      };
      set({ groups: updatedGroups });
    }
  },

  updateMemberComment: async (groupIndex: number, memberId: string, comment: string, userId: string) => {
    const { groups } = get();
    const updatedGroups = [...groups];
    if (updatedGroups[groupIndex]) {
      const group = updatedGroups[groupIndex];
      const memberCommentIndex = group.memberComments.findIndex(c => c.memberId === memberId);
      
      const newComment: GroupMemberComment = {
        memberId,
        comment,
        updatedAt: new Date().toISOString(),
        updatedBy: userId
      };

      if (memberCommentIndex >= 0) {
        group.memberComments[memberCommentIndex] = newComment;
      } else {
        group.memberComments.push(newComment);
      }

      group.updatedAt = new Date().toISOString();
      group.updatedBy = userId;
      
      set({ groups: updatedGroups });
    }
  }
}));