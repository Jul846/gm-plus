import { useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { useAuthStore } from '../store/authStore';
import { toast } from 'react-toastify';
import type { Role } from '../store/authStore';

export function useAuth() {
  const { setUser, setRole } = useAuthStore();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const userDocRef = doc(db, 'users', user.uid);
          const userDoc = await getDoc(userDocRef);
          
          const isSupreme = user.email === 'jugazel1@gmail.com';
          
          if (!userDoc.exists()) {
            // Créer le document utilisateur initial avec le rôle approprié
            const initialData = {
              email: user.email,
              role: isSupreme ? 'supreme' : 'user',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            
            await setDoc(userDocRef, initialData);
            setRole(initialData.role as Role);
            setUser(user);
            toast.success('Compte créé avec succès');
          } else {
            const userData = userDoc.data();
            // S'assurer que l'utilisateur suprême a toujours le bon rôle
            if (isSupreme && userData.role !== 'supreme') {
              await setDoc(userDocRef, {
                ...userData,
                role: 'supreme',
                updatedAt: new Date().toISOString()
              }, { merge: true });
              setRole('supreme');
            } else {
              setRole(userData.role as Role);
            }
            setUser(user);
          }
        } catch (error: any) {
          console.error('Error in auth process:', error);
          if (error.code === 'permission-denied') {
            toast.error('Accès refusé');
            auth.signOut();
          } else {
            toast.error('Erreur d\'authentification');
          }
          setRole(null);
          setUser(null);
        }
      } else {
        setUser(null);
        setRole(null);
      }
    });

    return () => unsubscribe();
  }, [setUser, setRole]);
}