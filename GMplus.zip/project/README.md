# Homogeneous Groups App

A web application for creating and managing homogeneous groups based on member attributes.

## Setup Instructions

1. Create a Firebase project at [Firebase Console](https://console.firebase.google.com)

2. Enable Authentication and Firestore in your Firebase project:
   - Go to Authentication > Sign-in method > Enable Email/Password
   - Go to Firestore Database > Create database > Start in production mode

3. Get your Firebase configuration:
   - Go to Project Settings > General
   - Scroll down to "Your apps"
   - Click the web icon (</>)
   - Register your app and copy the configuration

4. Create a `.env` file in the root directory:
   ```bash
   cp .env.example .env
   ```

5. Fill in your Firebase configuration values in the `.env` file

6. Install dependencies and start the development server:
   ```bash
   npm install
   npm run dev
   ```

## Features

- User authentication with role-based access
- Member management with detailed profiles
- Intelligent group creation based on:
  - Skill levels
  - Attendance frequency
  - Availability
- Administrative dashboard with analytics
- Super admin controls for user management